	    <?php include "includefiles/header.php"; ?>

<style>

     @media only screen and (max-width: 700px) {
	 
	.banner1 {
   
   
	   margin-top:12%;
	margin-left:0%;
	margin-right:0%;
      width:100%;height:60vh!important;float:left;position:relative;background-position:center;background-size:cover;background-repeat:no-repeat; padding:1px;
    
  }
  
 }
 /* for mobile  */

  .banner1 {
      /*background-image: url(uploads/banners/tratment_image.jpg);*/
      background-image: url(uploads/pagebanner/fistula.webp);
  }
</style>
</head>


<?php include "includefiles/header2.php";?>




<!--inner-banner--> 
<div class="inner-banner jarallax banner1">

</div>
<!--/inner-banner--> 


<!--START INNER CONTENT -->
<section class="pad">

<div class="main">

<


 	<!--row -->
<div class="row">
  <div class="col-sm-12">
    <div class="col-sm-5" style="margin-left:-20px!important;" >
      <center> <h2 class="page-title">FISTULA</h2> </center>
    <center> <img src="uploads/images/Fistula.webp" style="margin-top: 5%;" width="300" height="300"></center>
  </div>
    <div class="col-sm-7"  style="margin-top:5%;">
	<!--row -->
<div class="row">
<div class="margin-bottom">
<!-- Accordion begin --><div class="accordion_example1" style="margin-left:-20px!important;">	
	<!-- item1 --><div class="accordion_in "><div class="acc_head">What Is It</div><div class="acc_content"><h3 class="subheading text-green"></h3><p>Anal Fistula is an abnormal passage (communication) between the interior of the anal canal (or rectum) and the outer skin surface around the anus i.e - One Opening of the fistula (Internal opening) is inside the anus (or rectum) and another opening (External opening) is on skin surface around the anus. A tube like structure ( Fistula track) connect them.</p></div></div><!-- item1 -->
	<!-- item2 --><div class="accordion_in"><div class="acc_head">Symptoms</div><div class="acc_content"><p></p><h3 class="subheading text-green"></h3><ul class="list"><li>Persistant seropurulent (sticky) discharge of pus and/or stool from the external opening of the fistula.</li><li>Irritation of skin.</li><li>Itching.</li><li>Pain</li><li>Flatus (gas) escape from external opening.</li></ul>  </div></div><!-- item2 -->
	<!-- item3 --><div class="accordion_in"><div class="acc_head">Causes</div><div class="acc_content"><p></p><h3 class="subheading text-green"></h3><ul class="list"><li>Abscess</li><li>Tuberculosis.(T.B).</li><li>Cancer.</li><li>IBS (Inflamatory bowel Syndrome).</li><li>Ulcerative colitis.</li><li>Crohn's disease. </li></ul>  </div></div><!-- item3 -->
	<!-- item4 --><div class="accordion_in"><div class="acc_head">Diagnosis</div><div class="acc_content"><p></p><h3 class="subheading text-green"></h3><ul class="list"><li>Fistula Probing.</li><li>Fistulogram.</li><li>MRI.</li><li>Endorectal ultra sonography. </li></ul>  </div></div><!-- item4 -->
	
  <!-- item6 --><div class="accordion_in"><div class="acc_head">Types</div><div class="acc_content"><p></p><h3 class="subheading text-green"></h3><ul class="list"><li>Low anal (75%).</li><li>High anal (8%).</li><li>Subcutaneous(5%).</li><li>Ano- rectal (7%)</li><li>Ano- rectal (7%). </li></ul>  </div></div><!-- item6 -->				   
				   
				   
	</div><!-- Accordion end -->
</div>
</div>


  </div>
</div>





</div>
</section>
<!--/INNER CONTENT END -->


 
   
  <!-- footer -->


     <!-- footer -->

<?php include "includefiles/footer.php"; ?>
<!--/footer --> 

<!-- open/close --> 
<!--Navigation -->
<!-- open/close -->
<!--Navigation -->
<?php include "includefiles/navbar.php"; ?>
<!--/Navigation --><!--/Navigation --> 

<!-- department-menu --> 
<!--sidebar -->
<!--sidebar -->
<?php include "includefiles/sidebar.php"; ?>
<!--/sidebar --><!--/sidebar --> 
<!--/department-menu --> 

<!-- go-top-->
<?php include "includefiles/gotoup.php"; ?>
<!-- /go-top-->

  
<!-- /slide-out-div-->
<?php include "includefiles/scriptall.php";?>

</body>

</html> 
   
   
   
   
   
   



   
   
   

