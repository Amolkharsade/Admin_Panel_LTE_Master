<?php include "includefiles/header.php"; ?>

<style>

/*===========================================================================*/





.banner-wrap
{
-webkit-animation-delay: 2s!important; /* Chrome, Safari, Opera */
    animation-delay: 2s!important;
}



/*=========================================================================*/

 /* for tablet device*/
 /*for mobile portrate device*/
@media screen and (min-width:768px)and (max-width:1023px) {
    .banner-wrap
    {
       display:; 
    }
}

/* tablet device 768 and 1023 ===========================*/

}
/* tablet device 768 and 1023 ========*/


/*baneer mobile 767*/
@media only screen and (max-width: 767px) {
    .banner-wrap
    {
       display:; 
    }
}
/*banner 767 */

 




/*============================================================================*/
@media only screen and (min-width:768px)and (max-width:1023px)
{
    .banner-wrap{
  
   margin-top:5%!important;
  }
}
/*=============================================================================*/
@media only screen and (max-width:767px) {
  .banner-wrap{
  
   margin-top:5%!important;
  }
}
/*=============================================================================*/

/*=============================================================================*/
/* width 667*/
Landscape:

   @media only screen and (orientation:landscape) 
   {
  .banner-wrap{
  
   margin-top:-10%!important;
  }
}
/*=============================================================================*/

@media only screen and (max-width: 767px)
{
.rows {
	margin-bottom:-16%!important;
	width: 100%;
	float: left;
	margin: 0;
	padding: 0;
	display: block;
}
}

 


.slide1 {


      background-image: url(uploads/home_banner/slider1.webp);
       
    
}
.slide2 {
    background-image: url(uploads/home_banner/welcome1.webp);
   
}
.slide3 {

    background-image:url(uploads/home_banner/12yearsexp.webp);
}
.slide4 {
   
   /* 1one of the */
  

  background-image:url(uploads/home_banner/oneoffewfistulacenter.webp);
                                                  
 
} 

.slide5
{
    /**/
    
       /*global center*/
  
   background-image:url(uploads/home_banner/globalcentergm.webp);
   
       
}

.slide6
{      
     /*for your pain we care*/
 
     
   
      
     background-image: url(uploads/home_banner/foryourpain.webp);
    
}
.slide7
{        /*ethical medical */
   
  
     background-image:url(uploads/home_banner/ethical.webp);
}
.slide8
{
   
    
     /*prev fistula failed*/
   
    background-image:url(uploads/home_banner/111.webp);
}



.slide9
{     
    
      /*Hitech 1*/
    background-image:url(uploads/home_banner/hightechgmsh.webp);
 
}
/*white1*/




</style>



</head>

<?php include "includefiles/header2.php";?>


<!--banner-wrap -->
<div class="banner-wrap">
       
        
   

    
<!--slider -->

<div id="transition-timer-carousel" class="carousel slide " data-ride="carousel"> 

<!-- Indicators -->
<ol class="carousel-indicators">
<li  class="active"  data-target="#transition-timer-carousel" data-slide-to="1"></li>

<li  data-target="#transition-timer-carousel" data-slide-to="2"></li>

<li  data-target="#transition-timer-carousel" data-slide-to="3"></li>

<li  data-target="#transition-timer-carousel" data-slide-to="4"></li>
<li  data-target="#transition-timer-carousel" data-slide-to="5"></li>
<li  data-target="#transition-timer-carousel" data-slide-to="6"></li>
<li  data-target="#transition-timer-carousel" data-slide-to="7"></li>
<li  data-target="#transition-timer-carousel" data-slide-to="8"></li>
<li  data-target="#transition-timer-carousel" data-slide-to="9"></li>

</ol>


<!-- carousel-inner -->
<div class="carousel-inner" >
<!--slide1 -->
<div class="item  active " >
<div class="bgslide  slide1 " >
<!--caption -->
<div class="carousel-caption" >
<div class="child">
<h1 class="fadeInDown  animated animset"></h1>
<h1 class="fadeInLeft  animated animset"></h1><br> <br>

</div>
</div>
</div>
</div>
<!--/slide1 -->
<!--slide1 -->
<div class="item " >
<div class="bgslide  slide2 ">
<!--caption -->
<div class="carousel-caption">
<div class="child">

</p>
</div>
</div>
</div>
</div>
<!--/slide1 -->
<!--slide1 -->
<div class="item ">
<div class="bgslide  slide3 ">
<!--caption -->
<div class="carousel-caption">
<div class="child">

</div>
</div>
</div>
</div>
<!--/slide1 -->
<!--slide1 -->
<div class="item ">
<div class="bgslide  slide4 ">
<!--caption -->
<div class="carousel-caption">
<div class="child">
    <h1 class="fadeInDown  animated animset" style="color:#000000!important;  text-shadow: 2px 2px 5px white;">One Of The Few Center In The World<br> For Highest Success Rate of<br> Piles, Fissure and Fistula  </h1>

<h1 class="fadeInLeft  animated animset" style = "font-family:courier,arial,helvetica;"> </h1>

<p class="fadeInRight  animated animset" style="color: #FFFFFF;font-family:courier,arial,helvetica;"><strong></strong>
</p><!--caption -->

</div>
</div>
</div>
</div>
<!--/slide1 -->

<!--slide1 -->
<div class="item ">
<div class="bgslide  slide5 ">
<!--caption -->
<div class="carousel-caption">
<div class="child">
    <h1 class="fadeInDown  animated animset" style="color:#000000;  text-shadow: 2px 2px 5px white;"> Global Centre For Excellence
In Previously Failed & Complicated Surgeries </h1>

<h1 class="fadeInLeft  animated animset"> </h1>

<p class="fadeInRight  animated animset" style="color:#FFFFFF;font-family:courier,arial,helvetica;"> <strong></strong>
</p><!--caption -->
</div>
</div>
</div>
</div>
<!--/slide1 -->

<!--slide1 -->
<div class="item ">
<div class="bgslide  slide6 ">
<!--caption -->
<div class="carousel-caption">
<div class="child">
    <h1 class="fadeInDown  animated animset" style="color:#000000;  text-shadow: 2px 2px 5px white;">For Your Pain We Care </h1>

<h1 class="fadeInLeft  animated animset"> </h1>

<p class="fadeInRight  animated animset" style="color:#FFFFFF;font-family:courier,arial,helvetica;"><strong></strong>
</p><!--caption -->

</div>
</div>
</div>
</div>
<!--/slide1 -->

<!--slide1 -->  <!-- 7 slide -->
<div class="item ">
<div class="bgslide  slide7 ">
<!--caption -->
<div class="carousel-caption">
<div class="child">
<h1 class="fadeInDown  animated animset" style="color:#000000;  text-shadow: 2px 2px 5px white;">Ethical Medical Practice is Our First & Formost Concern</h1>
<h1 class="fadeInLeft  animated animset"> </h1>

<p class="fadeInRight  animated animset" style="color:#FFFFFF;font-family:courier,arial,helvetica;"><strong></strong>
</p><!--caption -->

</div>
</div>
</div>
</div>
<!--/slide1 -->
<!--slide1 -->
<div class="item ">
<div class="bgslide  slide8 ">
<!--caption -->
<div class="carousel-caption">
<div class="child">
    <h1 class="fadeInDown  animated animset" style="color:#000000;  text-shadow: 2px 2px 5px white;">Your  Previous  Fistula Surgery Failed ?<br> Dont Worry We Will Cure You !</h1>


<p class="fadeInRight  animated animset" style="color:	#FFFFFF;font-family:courier,arial,helvetica;"><strong></strong>
</p><!--caption -->

</div>
</div>
</div>

<div class="item ">
<div class="bgslide  slide9 ">
<!--caption -->
<div class="carousel-caption">
<div class="child">
    <h1 class="fadeInDown  animated animset" style="color:#000000;   text-shadow: 2px 2px 5px white;">Hi-Tech, Permanent And <br> Non Surgical Treatment</h1>


<p class="fadeInRight  animated animset" style="color:	#FFFFFF;font-family:courier,arial,helvetica;"><strong></strong>
</p><!--caption -->
<
</div>
</div>
</div>
</div>


 
</div>

<a class="left carousel-control" href="#transition-timer-carousel" data-slide="prev" style="background-image:inherit!important; padding-top:20px!important;top: -1%">
<span class="glyphicon glyphicon-chevron-left  fadeInLeft animated" style="font-size:0px!important;"></span></a>
<!--------------------------->

<a class="right carousel-control" href="#transition-timer-carousel" data-slide="next" style="background-image:inherit!important;padding-top:20px!important; top:5%">
<span class="glyphicon glyphicon-chevron-right  fadeInLeft animated" style="font-size:0px!important; padding-top:20px!important;" ></span></a>
</div>
<!--/slider -->

</div>
<!--banner-wrap -->




<!--chairman-section -->
<div class="chairman-section">
<div class="main">
<!--cm-message -->
<div class="cm-message" style="width:100%!important;">
<h2 class="heading">About Us</h2>
<div class="quote">
<p><strong>GOOD MORNING SUPERSPECIALITY HOSPITAL</strong> is well known center in India for advanced and painless treatment of anorectal disorders like Piles, Fissure & Fistula. The Center was founded by Dr. Sandip Bhosale.
</p>



<span class="link"><a href="our-director.php">READ  MORE</a></span></div>

</div>
<!--/m-message -->
<div></div>









</div>
</div>



<!-- doctor  open -->
<!--START INNER CONTENT -->
<section class="pad">
<div class="main">
<h2 class="page-title"> OUR SPECIALITIES </h2>
<h2 class="breadcrumb">

<!--row -->
<div class="rows">
<div class="margin-bottom">


<!--row --><div class="rows">
    <div class="margin-bottom-small2">
<!-- four-col --><div class="four-col courses"><p><img src="uploads/images/Piles.webp" alt="Piles" class="fullwidth"></p>





<a href="piles_details.php"><h2 class="subheading text-green text-center cus-h" style="font-size:20px!important;">PILES</h2></a>


</div>





<!-- /four-col --><!-- four-col --><div class="four-col courses"><p><img src="uploads/images/Fissure.webp" alt="Fissure " class="fullwidth"></p>





<a href="Fissure_details.php"><h2 class="subheading text-green text-center cus-h" style="font-size:20px!important;">  FISSURE</h2></a>



</div>





<!-- /four-col --><!-- four-col --><div class="four-col courses"><p><img src="uploads/images/Fistula.webp" alt="Fistula" class="fullwidth"></p>





<a href="Fistula_details.php"><h2 class="subheading text-green text-center cus-h"style="font-size:20px!important;"> FISTULA</h2></a>

</div>





<!-- /four-col --><!-- four-col --><div class="four-col last courses"><p><img src="uploads/images/Constipation.webp" alt="Constipation" class="fullwidth"></p>





<a href="constipation_details.php"><h2 class="subheading text-green text-center cus-h"style="font-size:20px!important;"> CONSTIPATION</h2></a>


</div>





<!-- /four-col --></div>


</div>


<!--row --><!--row --><div class="rows">
    <div class="margin-bottom-small2">
    <!-- four-col --><div class="four-col courses"><p><img src="uploads/images/Abcess.webp" alt="Abscess" class="fullwidth"></p>





<a href="Abscess_details.php"><h2 class="subheading text-green text-center cus-h"style="font-size:20px!important;">ABSCESS</h2></a>


</div>





<!-- /four-col --><!-- four-col --><div class="four-col courses"><p><img src="uploads/images/Pruritus-Ani.webp" alt="Pruritus-Ani" class="fullwidth"></p>





<a href="Pruritus_Ani_details.php"><h2 class="subheading text-green text-center cus-h"style="font-size:20px!important;">PRURITUS ANI</h2></a>



</div>

webp



<!-- /four-col --><!-- four-col --><div class="four-col courses"><p><img src="uploads/images/Rectal-Polyps.webp" alt="Rectal Polyps" class="fullwidth"></p>





<a href="Rectal_Polyps_details.php"><h2 class="subheading text-green text-center cus-h"style="font-size:20px!important;"> RECTAL POLYPS</h2></a>



</div>





<!-- /four-col --><!-- four-col --><div class="four-col last courses"><p><img src="uploads/images/Pilonidal-Sinus.webp" alt="Pilonidal Sinus" class="fullwidth"></p>





<a href="pilonidal_sinus_details.php"><h2 class="subheading text-green text-center cus-h"style="font-size:20px!important;"> PILONIDAL SINUS</h2></a>


 -->
</div>





<!-- /four-col --></div>


</div>


<!--row -->


</div>
</div>





</div>
</section>
<!--/INNER CONTENT END -->


<section class="pad1">
<div class="main">
<h2 class="page-title"> OUR TREATMENTS </h2>
<h2 class="breadcrumb"></h2>
<div class="rows">


<div class="margin-bottom" style="margin-botom:1%!important;">
<div class="row">
	<div class="col-sm-12">
	    
	    
	    <div class="col-sm-4">
<div class="courses"><p><img src="uploads/images/treatment/laser_surgery.webp" alt="laser-surgery." class="fullwidth"></p>

<a href="laser_surgery.php"><h2 class="subheading text-green text-center cus-h" style="font-size:20px!important;"> LASER SURGERY</h2></a>
</div>
</div>
		<div class="col-sm-4">
<div class="courses"><p><img src="uploads/images/treatment/Injection_Therapy.webp" alt="Injection Therapy" class="fullwidth"></p>
<a href="Injection_Therapy.php"><h2 class="subheading text-green text-center cus-h" style="font-size:20px!important;"> INJECTION THERAPY</h2></a>


</div>
</div>


<div class="col-sm-4">
<div class=" courses"><p><img src="uploads/images/treatment/soton_therapy.webp" alt="soton " class="fullwidth"></p>
<a href="seton.php"><h2 class="subheading text-green text-center cus-h" style="font-size:20px!important;"> SETON </h2></a>
</div>
</div>





</div>
</div>
<!--<br>-->
<div class="row">
	<div class="col-sm-12">
	    
	    <div class="col-sm-4">
<div class="courses"><p><img src="uploads/images/treatment/Barrons_Band.webp" alt="Barron's Band" class="fullwidth"></p>
<a href="Barrons_Brand.php"><h2 class="subheading text-green text-center cus-h" style="font-size:20px!important;"> BARRON'S BAND</h2></a>
</div>
</div>
	    
	    
		<div class="col-sm-4">
<div class="courses"><p><img src="uploads/images/treatment/Infrared_Coagulation_Therapy.webp" alt="Infrared Coagulation Therapy" class="fullwidth"></p>
<a href="infrared_coagulation.php"><h2 class="subheading text-green text-center cus-h" style="font-size:20px!important;">  INFRARED COAGULATION</h2></a>

</div>
</div>


<div class="col-sm-4">
<div class=" courses"><p><img src="uploads/images/treatment/Stapler_Surgery for_Piles.webp" alt="Stapler Surgery for Pile" class="fullwidth"></p>
<a href="stapler_surgery.php"><h2 class="subheading text-green text-center cus-h" style="font-size:20px!important;"> STAPLER SURGERY FOR PILES</h2></a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>



<!-- End Treatment -->


<!-- ============================================================ -->


<!--team-container -->
<section class="team-container jarallax" style="margin-top:5%">
<div class="main">
<h2 class="heading text-center">Team of Experts</h2>
<h4></h4>
<!--scroller -->
<div class="owl-demo4 owl-top-pad">

		<!--item1 -->
		<div class="item">
		<div class="hover-effect margin-bottom img-rouded"><img src="uploads/doctor/Dr.Team1.webp" alt=" Good morning specialists hospital" ></div>
		<p class="text-center doc-desig">
		<span class="subtitle lined">DR. SANDIP BHOSALE</span><br>
				Founder<br>(M.S.)<br>Consultant ProctoSurgeon. 		</p>
		
		</div>
		<!--/item1 -->	
		<!--item1 -->
		<div class="item">
		<div class="hover-effect margin-bottom img-rouded"> <img src="uploads/doctor/Dr.team2.webp" alt=" good morning specialists hospital" ></div>
	<p class="text-center doc-desig">
	
		</div>
		<!--/item1 -->	
		<!--item1 -->
		<div class="item">
		<div class="hover-effect margin-bottom img-rouded"><img src="uploads/doctor/Dr.Team_ashok.webp" alt="specialists hospital" ></div>
		<p class="text-center doc-desig">
	
		</div>
		<!--/item1 -->	
		<!--item1 -->
		<div class="item">
		<div class="hover-effect margin-bottom img-rouded"><img src="uploads/doctor/Dr.Team_devendra.webp" alt="good morning specialists hospital" ></div>
		<p class="text-center doc-desig">
		
		</div>
		<!--/item1 -->	
		<!--item1 -->
		<div class="item">
		<div class="hover-effect margin-bottom img-rouded"><img src="uploads/doctor/Dr.Team_prashant.webp" alt="specialists hospital" ></div>
		<p class="text-center doc-desig">
		
		</div>
		<!--/item1 -->	
		<!--item1 -->
		<div class="item">
		<div class="hover-effect margin-bottom img-rouded"><img src="uploads/doctor/Dr.team6.webp" alt="specialists hospital" ></div>
		<p class="text-center doc-desig">
	
		</div>
		<!--/item1 -->	
		<!--item1 -->
		<div class="item">
		<div class="hover-effect margin-bottom img-rouded"><img src="uploads/doctor/Dr.team7.webp" alt="good morning specialists hospital" ></div>
		<p class="text-center doc-desig">
	
		</div>
		<!--/item1 -->	
		<!--item1 -->
		<div class="item">
		<div class="hover-effect margin-bottom img-rouded"><img src="uploads/doctor/Dr.team8.webp" alt="good morning specialists hospital" ></div>
		<p class="text-center doc-desig">
		
		</div>
		<!--/item1 -->	
		<!--item1 -->
		<div class="item">
		<div class="hover-effect margin-bottom img-rouded"><img src="uploads/doctor/Dr.team9.webp" alt="specialists hospital" ></div>
		<p class="text-center doc-desig">
	
		</div>
		<!--/item1 -->	
	
	
<!--/item1 -->


</div>
<!--/scroller -->


</div>
</section>
<!--/team-container -->


<!--galery-->

<!--tesimonials -->
<section class="pad">
<div class="main">
<h2 class="heading headline">
<b>
<center><span >GOOD MORNING SUPERSPECIALITY HOSPITAL</span><br>
In the media </center>
 </b>
</h2>


<!-- two-col -->
<div class="one-col">
<!--news scroll -->
<div class="owl-demo news-scroll">


<!--item1 -->
<div class="item">
<!--row -->
<div class="margin-bottom rows">
<div class="thumb-wrap"><img src="uploads/news/media-2.webp" alt="media_2"></div>
<div class="text-wrap">
<p><span class="text-green bold">Busting misconceptions about piles</span>
</p>

<br></p>
</div>
</div>
<!--/row -->

</div>
<!--/item1 -->

<!--item1 -->
<div class="item">
<!--row -->
<div class="margin-bottom rows">
<div class="thumb-wrap"><img src="uploads/news/media-3.webp" alt="media 4"></div>
<div class="text-wrap">
<p><span class="text-green bold">An Insight into symptoms <br> types and causes of hemorrhoids </span></p>

<br></p>
</div>
</div>
<!--/row -->

</div>
<!--/item1 -->

<!--item1 -->
<div class="item">
<!--row -->
<div class="margin-bottom rows">
<div class="thumb-wrap"><img src="uploads/news/media-4.webp" alt="news 4"></div>
<div class="text-wrap">
<p><span class="text-green bold">Understanding Piles And Fissure</span></p>

<br></p>
</div>
</div>
<!--/row -->

</div>
<!--/item1 -->


<!--item1 -->
<div class="item">
<!--row -->
<div class="margin-bottom rows">
<div class="thumb-wrap"><img src="uploads/news/media-6.webp" alt="news 4"></div>
<div class="text-wrap">
<p><span class="text-green bold">Advance treatments to<br> solve fistula problems <br><br> <br><br><br><br><br><br></span></p>


</div>

</div>
<!--/row -->

</div>
<!--/item1 -->






<!--item1 -->
<div class="item">
<!--row -->
<div class="margin-bottom rows">
<div class="thumb-wrap"><img src="uploads/news/media-8.webp" alt="news 4"></div>
<div class="text-wrap">
<p><span class="text-green bold">&nbsp&nbsp&nbspपथ्य पाळा -  मूळव्याध  टाळा   <br><br><br> </span></p>


</div>
</div>
<!--/row -->

</div>
<!--/item1 -->

<!--item1 -->
<div class="item">
<!--row -->
<div class="margin-bottom rows">
<div class="thumb-wrap"><img src="uploads/news/media-9.webp" alt="news 4"></div>
<div class="text-wrap">
<p><span class="text-green bold">मूळव्याध , भगंदर  व क्षारसूत्र  चिकित्सा <br> <br><br></span></p>


</div>
</div>
<!--/row -->

</div>
<!--/item1 -->

<!--item1 -->
<div class="item">
<!--row -->
<div class="margin-bottom rows">
<div class="thumb-wrap"><img src="uploads/news/media-10.webp" alt="news 4"></div>
<div class="text-wrap">
<p><span class="text-green bold">मूळव्याध , भगंदर  व क्षारसूत्र <br> 
<br><br></span></p>

</div>
</div>
<!--/row -->

</div>
<!--/item1 -->

<!--item1 -->
<div class="item">
<!--row -->
<div class="margin-bottom rows">
<div class="thumb-wrap"><img src="uploads/news/media-11.webp" alt="news 4"></div>
<div class="text-wrap">
<p><span class="text-green bold">भगंदरबाबद  जागरूकता  हवी <br>
<br><br></span></p>


</div>
</div>
<!--/row -->

</div>
<!--/item1 -->

<!--item1 -->
<div class="item">
<!--row -->
<div class="margin-bottom rows">
<div class="thumb-wrap"><img src="uploads/news/media-13.webp" alt="news 4"></div>
<div class="text-wrap">
<p><span class="text-green bold">मूळव्याध  उपचार - पद्धत  <br><br><br> </span></p>


</div>
</div>
<!--/row -->

</div>
<!--/item1 -->

<!--item1 -->
<div class="item">
<!--row -->
<div class="margin-bottom rows">
<div class="thumb-wrap"><img src="uploads/news/media-14.webp" alt="news 4"></div>
<div class="text-wrap">
<p><span class="text-green bold">मुळव्यादबाबद  समज आणि  गैरसमज  <br> 
<br><br></span></p>


</div>
</div>
<!--/row -->

</div>
<!--/item1 -->

<!--item1 -->
<div class="item">
<!--row -->
<div class="margin-bottom rows">
<div class="thumb-wrap"><img src="uploads/news/media-15.webp" alt="news 4"></div>
<div class="text-wrap">
<p><span class="text-green bold">Busting myths about fistula <br><br><br> </span></p>


</div>
</div>
<!--/row -->

</div>
<!--/item1 -->

</div>
<!--/news scroll -->

</div>
<!-- /two-col -->

</div>
</section>
<!--/tesimonials -->

<!-- gallery-->




<!--gallery close -->
<!-- testimonial section  start -->
<section  class="pad">
    <div class="main">
<div class="demo">
    <h2 class="heading headline">
<b>
<center><span> ABOUT GOOD MORNING SUPERSPECIALITY HOSPITAL</span><br>
Patient Says !</center>
 </b>
</h2>
   
    <div class="container" style="width:100%">
        
        
        <div class="row">
            
            <div class="col-md-12"  style="width:100%">
                <div id="testimonial-slider" class="owl-carousel">
                    
                 
                    
                    <div class="testimonial">
                        <div class="testimonial-content">
                            <div class="testimonial-icon">
                                <i class="fa fa-quote-left"></i>
                            </div>
                            <p class="description">
                                I am 32 years old male had suffered from anal pain and bleeding since 3 year.After every motion there is a pain bleeding.I could not walk without taking a hot sitz bath. Working in office is very uncomfortable. Long trips in a car were out of question. I tried Ayurvedic, allopathic and homeopathic medicine also but I got relief for few days only. When I was consult to Dr.Bhosale at Dr. Bhosales Piles treatment center They diagnosed my disease as fissure in ano. They given me treatment which is totally painless and discharged me on Next day. Now I am free from pain and bleeding. All thanks to Dr.Bhosale and his loveable staff.
                                      <a href="testimonials.php">Read More...</a><br> 
                            </p>
                        </div>
                        <h3 class="title">MR. MANISH JOSHI</h3>
                        <span class="post">(IT ENGG.)</span>
                    </div>
 
                    <div class="testimonial">
                        <div class="testimonial-content">
                            <div class="testimonial-icon">
                                <i class="fa fa-quote-left"></i>
                            </div>
                            <p class="description">
                                I suffered from severe piles since 5 yrs. It got so bad that when I went to toilet, the toilet bowl was dark red from blood and some mass comes out through anus. Finally I had enough and I consult to Dr.Bhosale. who said that I was suffering from internal 2nd degree hemorrhoids. Doctor recommend me Laser with band application. They do the procedure in the morning and discharged me at Next day Next day from the procedure my bleeding was stoped. Now I am free from that horrible red dragon.
                                <a href="testimonials.php">Read More...</a><br> 
                            </p>
                        </div>
                        <h3 class="title">MR. ATUL GANDHI</h3>
                        <span class="post">(CIVIL ENGG.)</span>
                    </div>
                    
                    <div class="testimonial">
                        <div class="testimonial-content">
                            <div class="testimonial-icon">
                                <i class="fa fa-quote-left"></i>
                            </div>
                            <p class="description">
                                I am 45 years old male,from Shivajinagar, suffered from fistula since 12 years. I had operated 3 times for same but in a few days it get reoccurred. 4th time doctor rejected my case and told me that there is chance of incontinence (loss of control on motion) after repeated surgery , Then that surgeon reffered me to Dr. Bhosale for further management. Dr.Bhosale adviced me Seton treatment for fistula. I Completed my treatment without any hospital admission and without painful daily dressings. And since one and half year I don’t have any complain about my fistula. Thanks to Seton.
                                <a href="testimonials.php">Read More...</a><br> 
                            </p>
                        </div>
                        <h3 class="title">MR. SHARMA</h3>
                        <span class="post">(BUSINESSMAN ,SHIVAJINAGAR)</span>
                    </div>
 
                    <div class="testimonial">
                        <div class="testimonial-content">
                            <div class="testimonial-icon">
                                <i class="fa fa-quote-left"></i>
                            </div>
                            <p class="description">
                                After my delivery I suffered from severe burning and pain after motion and bleeding also. I could not seat to feed my baby. I got Dr. Bhosale’s reference from my colleague. I meet Dr. Bhosale and he told me that I was suffering from very common problem in pregnancy and followed by delivery. It was fissure. He given me some medicine and ointment also, I got relief from that pain in a weak and I continued that medicine for few day. And now I am free from pain.
                                <a href="testimonials.php">Read More...</a><br> 
                            </p>
                        </div>
                        <h3 class="title">MRS. KANCHAN PATIL</h3>
                        <span class="post">(HOUSE WIFE)</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--
===-->
</div>
</section><!-- section close -->

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.theme.min.css">
 <style>
.demo{ background: #f8f8f8; }
.testimonial{
    margin: 0 20px 40px;
}
.testimonial .testimonial-content{
    padding: 35px 25px 35px 50px;
    margin-bottom: 35px;
    background: #fff;
    border: 1px solid #f0f0f0;
    position: relative;
}
.testimonial .testimonial-content:after{
    content: "";
    display: inline-block;
    width: 20px;
    height: 20px;
    background: #fff;
    position: absolute;
    bottom: -10px;
    left: 22px;
    transform: rotate(45deg);
}
.testimonial-content .testimonial-icon{
    width: 50px;
    height: 45px;
    background: #ff4242;
    text-align: center;
    font-size: 22px;
    color: #fff;
    line-height: 42px;
    position: absolute;
    top: 37px;
    left: -19px;
}
.testimonial-content .testimonial-icon:before{
    content: "";
    border-bottom: 16px solid #e41212;
    border-left: 18px solid transparent;
    position: absolute;
    top: -16px;
    left: 1px;
}
.testimonial .description{
    font-size: 15px;
    font-style: italic;
    color: #8a8a8a;
    line-height: 23px;
    margin: 0;
}
.testimonial .title{
    display: block;
    font-size: 18px;
    font-weight: 700;
    color: #525252;
    text-transform: capitalize;
    letter-spacing: 1px;
    margin: 0 0 5px 0;
}
.testimonial .post{
    display: block;
    font-size: 14px;
    color: #ff4242;
}
.owl-theme .owl-controls{
    margin-top: 20px;
}
.owl-theme .owl-controls .owl-page span{
    background: #ccc;
    opacity: 1;
    transition: all 0.4s ease 0s;
}
.owl-theme .owl-controls .owl-page.active span,
.owl-theme .owl-controls.clickable .owl-page:hover span{
    background: #ff4242;
}
</style>


<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js"></script>
 <script>
$(document).ready(function(){
    $("#testimonial-slider").owlCarousel({
        items:3,
        itemsDesktop:[1000,3],
        itemsDesktopSmall:[980,2],
        itemsTablet:[768,2],
        itemsMobile:[650,1],
        pagination:true,
        navigation:false,
        slideSpeed:1000,
        autoPlay:true
    });
});
</script>



<!-- testimonial code end  =================================================-->


<?php include "includefiles/footer.php"; ?>
<!--/footer --> 

<
<?php include "includefiles/navbar.php"; ?>
<!--/Navigation --><!--/Navigation --> 

<!-- department-menu --> 
<!--sidebar -->
<!--sidebar -->
<?php include "includefiles/sidebar.php"; ?>

<!-- go-top-->
<?php include "includefiles/gotoup.php"; ?>
<!-- /go-top-->


<!-- /slide-out-div-->
<?php include "includefiles/scriptindex.php"; ?>
</body>

</html>