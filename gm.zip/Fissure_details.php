	    <?php include "includefiles/header.php"; ?>

<style>

     @media only screen and (max-width: 700px) {
	 
	.banner1 {
    
	   margin-top:12%;
	margin-left:0%;
	margin-right:0%;
      width:100%;height:60vh!important;float:left;position:relative;background-position:center;background-size:cover;background-repeat:no-repeat; padding:1px;
    
  }
  
 }
 /* for mobile  */


  .banner1 {
    
      background-image: url(uploads/pagebanner/fissure.webp);
  }
</style>
</head>


<?php include "includefiles/header2.php";?>




<!--inner-banner--> 
<div class="inner-banner jarallax banner1">

</div>
<!--/inner-banner--> 


<!--START INNER CONTENT -->
<section class="pad">

<div class="main">

<div class="row">
  <div class="col-sm-12">
    <div class="col-sm-5" style="margin-left:-18px!important;">
    <center> <h2 class="page-title">FISSURE </h2>
      <img src="uploads/images/Fissure.webp" style="margin-top: 5%;" width="300" height="300"></center>
  </div>
    <div class="col-sm-7"  style="margin-top:5%;" >
	<!--row -->
<div class="row">
<div class="margin-bottom">
<!-- Accordion begin --><div class="accordion_example1" style="margin-left:-20px!important;">	
	<!-- item1 --><div class="accordion_in "><div class="acc_head">What Is It</div><div class="acc_content"><h3 class="subheading text-green"></h3><p>Anal Fissure is longitudinal tear in the lower end of anus. It is the most painful condition affecting the anal region. It commonly seen in young patients.</p></div></div><!-- item1 -->
	<!-- item2 --><div class="accordion_in"><div class="acc_head">Symptoms</div><div class="acc_content"><p></p><h3 class="subheading text-green"></h3><ul class="list"><li>Severe burning and pain during and after passing stool.</li><li>severe constipation Drop of blood or streak of fresh blood during defecation.</li><li>sentinel piles (Tag of skin at the outer end of anus).</li><li>Itching.</li><li>Hard stool (pellet like).</li></ul>  </div></div><!-- item2 -->
	<!-- item3 --><div class="accordion_in"><div class="acc_head">Causes</div><div class="acc_content"><p></p><h3 class="subheading text-green"></h3><ul class="list"><li>Hard stool.</li><li>surgical Procedure (Piles surgery).</li><li>spincter hypertonia (spasm of anus)</li><li>Repeated child birth.</li><li>Excessive use of ointments.</li><li>Excessive use of laxatives. </li></ul>  </div></div><!-- item3 -->
	<!-- item4 --><div class="accordion_in"><div class="acc_head">Diagnosis</div><div class="acc_content"><p></p><h3 class="subheading text-green"></h3><ul class="list"><li>Per rectal examination with lignocaine jelly application.</li><li>Proctoscopy is contraindicated because the condition is very painful. (If require can be done under general anasthesia).</li></ul>  </div></div><!-- item4 -->
	
  <!-- item6 --><div class="accordion_in"><div class="acc_head">Complication</div><div class="acc_content"><p></p><h3 class="subheading text-green"></h3><ul class="list"><li>Anemia.</li><li>Pain.</li><li>Infection.</li><li>Fistula</li></ul>  </div></div><!-- item6 -->				   
				   
				   
	</div><!-- Accordion end -->
</div>
</div>


  </div>
</div>





</div>
</section>
<!--/INNER CONTENT END -->


 
   
  <!-- footer -->


     <!-- footer -->

<?php include "includefiles/footer.php"; ?>
<!--/footer --> 

<!-- open/close --> 
<!--Navigation -->
<!-- open/close -->
<!--Navigation -->
<?php include "includefiles/navbar.php"; ?>
<!--/Navigation --><!--/Navigation --> 


<?php include "includefiles/sidebar.php"; ?>
<!--/sidebar --><!--/sidebar --> 
<!--/department-menu --> 

<!-- go-top-->
<?php include "includefiles/gotoup.php"; ?>
<!-- /go-top-->


<!-- /slide-out-div-->
<?php include "includefiles/scriptall.php";?>

</body>

</html> 
   
   
   
   
   
   



   
   
   

