	    <?php include "includefiles/header.php"; ?>
        <?php //include "includefiles/connection.php"; ?>
<style>

   @media only screen and (max-width: 700px) {
	 
	.banner1 {
   
	  
	   margin-top:12%;
	margin-left:0%;
	margin-right:0%;
      width:100%;height:75vh!important;float:left;position:relative;background-position:center;background-size:cover;background-repeat:no-repeat; padding:1px;
    
  }
  
 }
 /* for mobile  */


  .banner1 {
      /*background-image: url(uploads/pagebanner/27.jpg);*/
       background-image: url(uploads/pagebanner/Contact2.webp);
      
      
  }
</style>
</head>


<?php include "includefiles/header2.php";?>


<!--inner-banner--> 
<div class="inner-banner jarallax banner1">

</div>
<!--/inner-banner--> 


<!--START INNER CONTENT -->
<section class="pad">
<div class="main">
<h2 class="page-title">Contact Us</h2>
<!--<h2 class="breadcrumb">
<a href="index.php"><span>Home</span></a> -  Contact Us</h2>-->


<!--row -->

</div>
</section> 
<!--/INNER CONTENT END -->


 
   
  <!-- footer -->

<?php include "includefiles/footer.php"; ?>
<!--/footer --> 

<!-- open/close --> 
<!--Navigation -->
<!-- open/close -->
<!--Navigation -->
<?php include "includefiles/navbar.php"; ?>
<!--/Navigation --><!--/Navigation --> 

<!-- department-menu --> 
<!--sidebar -->
<!--sidebar -->
<?php include "includefiles/sidebar.php"; ?>
<!--/sidebar --><!--/sidebar --> 
<!--/department-menu --> 

<!-- go-top-->
<?php include "includefiles/gotoup.php"; ?>
<!-- /go-top-->

<!-- popup form -->
 <!-- slide-out-div-->
<?php //include "includefiles/popup.php"; ?>
<!--/footer --> 

<!-- open/close --> 
<!--Navigation -->
<!-- open/close -->
<!--Navigation -->

<!--/Navigation --><!--/Navigation --> 

<!-- department-menu --> 
<!--sidebar -->
<!--sidebar -->

<!--/sidebar --><!--/sidebar --> 
<!--/department-menu --> 


 <!-- go-top-->

<!-- /go-top-->

<!-- popup form -->
<!-- popup form -->
<!--counter -->
<script src="assets/js/counter/waypoints.min.js"></script>
<script src="assets/js/counter/jquery.counterup.min.js"></script>
<script>
    jQuery(document).ready(function( $ ) {
        $('.counter').counterUp({
            delay: 10,
            time: 1000
        });
    });
</script>




<!--parallax -->
<script src="assets/js/parallax/jquery.min.js"></script>
<script src="assets/js/parallax/jarallax.js"></script>
<script >
         /* init Jarallax */
	$('.jarallax').jarallax({
	speed: 0.5,
	imgWidth: 1366,
	imgHeight: 768
})

</script>



<!--search script -->
<script src="assets/js/search/classie.js" ></script>
<script src="assets/js/search/uisearch.js" ></script>
<script>
new UISearch( document.getElementById( 'sb-search' ) );
</script>




<!--slider-->
<!--<script src="js/slider/jquery-1.js"></script> -->
<script src="assets/js/slider/bootstrap.js"></script>


<!--menu js -->
<!--<script src='js/hamburger/jquery.min.js'></script> -->
<script  src="assets/js/hamburger/menu.js"></script>



<!--before after js -->
<script src="assets/js/beforeafter/cocoen.min.js"></script>
<script>
	document.addEventListener('DOMContentLoaded', function(){
	new Cocoen();
	});

</script>

<!--Accordian -->
<script  src="assets/js/accordian/jquery-1.10.1.min.js"></script>
<script  src="assets/js/accordian/smk-accordion.js"></script>
<script >
		jQuery(document).ready(function($){

			$(".accordion_example1").smk_Accordion();


		});
	</script>

<!--tabs -->
<script src="assets/js/tabs/jquery.min.js"></script>
<script src="assets/js/tabs/SimpleTabs.js" ></script>

<!--sidebar js -->
<!--<script src="js/sidebar/jquery-2.2.3.min.js" defer></script>  -->
<script src="assets/js/sidebar/sidebar.js" defer></script>

   <!--scroller -->
<!--<script src="js/carousel/jquery-1.9.1.min.js"></script>  -->
<script src="assets/js/carousel/owl.carousel.js"></script>
<script src="assets/js/carousel/owl.js"></script>



<!-- BACK TO TOP -->
<script  src="assets/js/backtotop/fixedbar.js"></script>

<!--slideout tab -->

<script src="assets/js/slidetab/jquery.tabSlideOut.v1.3.js"></script>



<!-- sticky js -->
<script>
    function init() {
        window.addEventListener('scroll', function(e){
            var distanceY = window.pageYOffset || document.documentElement.scrollTop,
                shrinkOn = 40,
                header = document.querySelector("header");
            if (distanceY > shrinkOn) {
                classie.add(header,"smaller");
            } else {
                if (classie.has(header,"smaller")) {
                    classie.remove(header,"smaller");
                }
            }
        });
    }
    window.onload = init();

      function recaptchaCallbackAppointment()
   {
     var bookbutton = document.getElementById("Submit_btn_appointment");
     document.getElementById('Submit_btn_appointment').disabled = false;
   }

        $(document).ready(function(){
      $( "#email,#name,#txt_dob,#phone,#txt_appdate,#message,#txtInput " ).on( "copy cut paste drop", function() {
              return false;
      });
    });

</script>

<script >
$(document).ready(function()
{
    $("#department").change(function()
    {
        //alert('Hai');
        var id=$(this).val();

        var dataString = 'id='+ id;
        $.ajax
        ({
        type: "POST",
        url: "https://goodmorninghospital.blucorsys.com/ajaxapp.php",
        data: dataString,
        cache: false,
        success: function(html)
        {
        //alert(html);
        $("#select_doctor").html(html);
        }
        });

    });

        $("#select_doctor").change(function()
    {
        //alert('Hai');
        var obj = [];
        var doc_id=$(this).val();
        var dataString2 = 'doc_id='+ doc_id;
        $.ajax
        ({
            type: "POST",
            url: "https://goodmorninghospital.blucorsys.com/ajaxappday.php",
            data: dataString2,
            cache: false,
            global: false,
            async:false,
            success: function(msg)
            {
                    //alert(msg);
                                document.getElementById("hiddenvalue").value='';
                    document.getElementById("hiddenvalue").value = msg;

            }
        });

    });

});
</script>

<!-- datepicker -->
<script src="../code.jquery.com/ui/1.9.2/jquery-ui.min.js"
  integrity="sha256-eEa1kEtgK9ZL6h60VXwDsJ2rxYCwfxi40VZ9E0XwoEA="
  crossorigin="anonymous"></script>
<!-- <script  src="https://code.jquery.com/ui/1.9.2/jquery-ui.js"></script> -->
<link rel="stylesheet" href="../code.jquery.com/ui/1.9.2/themes/base/jquery-ui.css">
<script>

$(document).ready(function(){
    //var hval=document.getElementById('hiddenvalue').value;
    //var obj = JSON.parse(hval);
    //alert(obj);
        $("#txt_appdate").datepicker({
        numberOfMonths: 1,
        dateFormat: 'dd/mm/yy',
        minDate: +1,
        beforeShowDay: enabledays  
            // onSelect: function () {
            // $('#DepartDate').datepicker('option', {
            // minDate: $(this).datepicker('getDate')
            // });
            // }
    });

    function enabledays(date){
        var day = date.getDay(), Sunday = 0, Monday = 1, Tuesday = 2, Wednesday = 3, Thursday = 4, Friday = 5, Saturday = 6;

        var hval = document.getElementById('hiddenvalue').value;

            
            var enbleDays = hval;

                        for (var i = 0; i < enbleDays.length; i++) {
                if (day == enbleDays[i][0]) {
                    return [true];
                }
            }
            return [false];


    }

});


$(function() {
$( "#txt_dob" ).datepicker({
dateFormat: 'dd/mm/yy',
changeMonth: true,
changeYear: true,
yearRange: '-100:+0'
});
});
</script>

<script src="assets/js/gg-captcha.js"></script>

</body>

</html> 
   

   
   

