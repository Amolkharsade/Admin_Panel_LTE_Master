	    <!DOCTYPE html>
<html lang="en">


<!-- Mirrored from www.specialistshospital.com/doctors/drkr-rajappan by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 17 Dec 2020 09:47:59 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<meta charset="utf-8" />
<title>Dr. K. R. Rajappan | Specialist Hospital Ernakulam</title>
<meta name="description" content="Dr. K. R. Rajappan | Specialist Hospital Ernakulam" />
<meta name="keywords" content="Knee Arthroscopy in Kochi, Top Cosmetic Surgeons in Kochi , Top Cosmetic Surgeons in India, Top Cosmetic Surgeons Kochi, Top Cosmetic Surgeons India"/>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<link rel="shortcut icon" href="../assets/images/hlogo.png">
<link rel="stylesheet"  href="../assets/css/normalize.css" />
<link rel="stylesheet"  href="../assets/css/specialist-all.css" />
<link rel="stylesheet"  href="../assets/css/hamburger.css" />
<link rel="stylesheet"  href="../assets/css/slider.css" />
<link rel="stylesheet"  href="../assets/css/font-awesome.css" />
<link rel="stylesheet"  href="../assets/css/search.css" />
<link rel="stylesheet"  href="../assets/css/animate.css" />
<link rel="stylesheet"  href="../assets/css/carousel.css" />
<link rel="stylesheet"  href="../assets/css/hover-style.css" />
<link rel="stylesheet"  href="../assets/css/popup.css" />
<link rel="stylesheet"  href="../assets/css/navside.css" />
<link rel="stylesheet"  href="../assets/css/before-after.css" />
<link rel="stylesheet"  href="../assets/css/smk-accordion.css" />
<link rel="stylesheet"  href="../assets/css/lightbox.css" />
<link rel="stylesheet"  href="../assets/css/tabs.css" />


<!-- Preloader -->
<script src="../assets/js/loader/jquery.min.js"></script>
<script>
	//<![CDATA[
		$(window).load(function() { // makes sure the whole site is loaded
			$('#status').fadeOut(); // will first fade out the loading animation
			$('#preloader').delay(350).fadeOut('slow'); // will fade out the white DIV that covers the website.
			$('body').delay(350).css({'overflow':'visible'});
		})
	//]]>
</script> 

<script src='../../www.google.com/recaptcha/api.js'></script>

<style>
.banner1 {
    background-image: url(uploads/banners/Doctors.jpg);
}
</style>
</head>



<body>

<!--preloader -->
<div id="preloader">
<div id="status">&nbsp;</div>
</div>
<!--/preloader -->

<!-- header -->
<header>
<div class="main">

<!--Logo -->
<div class="logo">
<a href="index.php"><img src="../assets/images/hlogo.png" alt="specialists hospital" height="100" width="100"></a></div>
<!--/logo -->

<!-- top-container -->
<div class="top-container">

<!--search-icon -->


<!--<div class="search-conaiinter">
<div class="expanding-div">
<div id="sb-search" class="sb-search">
<form  method="get" action="#">
<input class="sb-search-input" placeholder="Enter your search term..." type="text" value="" name="search" id="search">
<input class="sb-search-submit" type="submit" value="">
<span class="sb-icon-search"></span>
</form>
</div>
</div>
</div> -->
<!--/search-icon -->

<!--call -->

<div class="call ">
	
<!--<div class="tooltip">
<b class="hidden-xs">
<div class="fullwidth">	

<a href="tel:04842887800">0484-2887800</a> <span>(Physician)</span><br><a href="tel:9446501369">9446501369</a><span>(Proctologist) </span><br><a
href="tel:9072888893">9072888893</a><span>(Surgeons) </span><br><a 
href="tel:9633507632">9633507632</a><span>(Anaesthetist)</span></div>
</b>
</div> -->

<div class="res-col">
<a href="tel:88886 00006">88886 00006</a> <br><span>(Physician)</span><!--<br><a href="tel:88886 00006">88886 00006</a><span>(Proctologist) </span><br><a
href="tel:88886 00006">88886 00006</a><span>(Surgeons) </span><br><a 
href="tel:88886 00006">88886 00006</a><span>(Anaesthetist)</span>--></div>

</div>

<!--/call -->

<!--map -->

<div class="map">
<div class="res-col-map">
<a href="https://goo.gl/maps/StqFM8Vb37Z8DZ6a7">
<!--<a href="https://www.google.com/maps/place/Specialists'+Hospital/@9.9904987,76.2859211,15z/data=!4m2!3m1!1s0x0:0x7206e12aa393d2d4?ved=2ahUKEwic0s2hi9bgAhXMAnIKHV9GAbwQ_BIwEXoECAUQCA" target="_blank">
-->Map &amp;Directions<br> 
<span>Click Here</span>
</a>
</div> 

<br>

<!--<div class="ask-expert"><a href="ask-an-expert.php"><br>ASK AN EXPERT
<!-- <span>Click Here</span> -->

<!--</a></div> -->

</div>

</a>
<!--/map -->



<!-- d-button-->
<span class="d-button"><a href="#" id="open-right">OUR DEPARTMENTS</a></span>
<!-- d-button-->



<!--nav -->
<nav>
<div class="menu-icon">
<div class="menu-button">MENU</div>
</div>
</nav>
<!--/nav -->

</div>
<!-- /top-container -->







</div>
</header>
<!-- /header -->




<!--inner-banner--> 
<div class="inner-banner jarallax banner1">

</div>
<!--/inner-banner--> 


<!--START INNER CONTENT -->
<section class="pad">
<div class="main">
<h2 class="page-title">Doctors</h2>
<h2 class="breadcrumb">
<a href="../index.html"><span>Home</span></a> -  <a href="../doctors.html">Doctors</a> - Dr. K. R. Rajappan</h2>

<!--aside -->
<div class="aside pad-right">
<div class="hover-effect img-rouded margin-bottom"><img src="../uploads/doctor/8662210861kr-rajappan.jpg" alt="specialists hospital" ></div>
<p class="text-center">
<span class="subtitle lined">Dr. K. R. Rajappan</span><br>
<br>
Director Senior Consultant. Plastic, Cosmetic and Microvascular Surgeon</p>
</div>
<!--/aside -->


<!--summary -->
<div class="summary">



		<!-- <h2 class="subheading text-blue bold">
		About
		</h2> -->

		<p class="justify">Dr K.R.Rajappan worked as First Plastic Surgery teacher,Kottayam Medical College and worked for 7 years.After Medical College work as a Teacher and organiser of Plastic Surgery unit in Kottayam Medical College,left service to do private plastic surgery in the Private sector all over Kerala from 1975 to 1983 on a scheme of free service to poor.</p>
<p class="justify">Started first Plastic Surgery Hospital at Ernakulam in the Private sector in Kerala on 1983-maintaining the free service scheme under a charitable trust.</p>
<p class="justify">&nbsp;</p>
<h2 class="subheading text-blue bold">Medical Qualifications</h2>
<ul class="list">
<li>MBBS- S.C.B&nbsp; Medical College, Cuttack ,Orissa - (1960)</li>
<li>MS in Plastic&nbsp; Surgery- Prince of Wales Medical College, Patna, Bihar -(1967)</li>
</ul>
</div>
<!--/summary -->








</div>
</section>
<!--/INNER CONTENT END -->




<!-- footer -->

<!--/footer -->











<!-- open/close -->
<!--Navigation -->
<!-- open/close -->
<!--Navigation -->
<section class="overlay-menu">
<div class="menu-icon"><div class="closebutton"></div></div>

<div class="container">
<div class="row">
<!--menu --><div class="columns menu-col"><h2>Main Pages</h2>
<ul>
<li><a href="index.php">Home</a></li>
<li><a href="appointment.php">Appointment</a></li>
<li><a href="doctors.php">Our Doctors</a></li>
<li><a href="health-checkup-package.php">Health checkup packages</a></li>
<li><a href="news.php">News &amp; Events</a></li>
<li><a href="testimonials.php">Patient Testimonials</a></li>
<li><a href="courses.php">Courses</a></li>
<!--<li><a href="blog/index.html">Blog</a></li>-->
<!--<li><a href="careers.php">Careers</a></li> -->
<li><a href="contact-us.php">Contact Us</a></li>
</ul>
</div>
<!--menu --><div class="columns menu-col"><h2>Free treatments</h2>
<ul>
<li><a href="free-cancer-treatment-in-kerala.php" target="_blank">Snehathanal</a></li>
<li><a href="fclps.php">Free Cleft Lip &amp; Palate Surgery (Smile Train)</a></li>
<li><a href="dialysis-treatment.php">Dialysis Treatment</a></li>
</ul>
</div>
<!--menu --><!--menu --><div class="columns menu-col"><h2>About Us</h2>
<ul>
<li><a href="about-us.php">Overview</a></li>
<li><a href="our-director.php">Our Director</a></li>
<li><a href="mission.php">Mission</a></li>
<li><a href="vision.php">Vision</a></li>
<li><a href="milestone.php">Milestone</a></li>
</ul>
</div>
<!--menu -->	  	   <!--menu --><div class="columns menu-col"><h2>Facilities Available</h2>
<ul>
<li><a href="laboratory.php">Laboratory</a></li>
<li><a href="insurance.php">Insurance</a></li>
<li><a href="emergency-services.php">Emergency Services</a></li>
<li><a href="international-patients.php">For International Patients</a></li>
</ul>
</div>
<!--menu --><!--menu --><div class="columns menu-col"><h2>Media Gallery</h2>
<ul>
<li><a href="videos.php">Video Gallery</a></li>
<li><a href="gallery.php">Image Gallery</a></li>
<!--<li><a href="before-after.html">Before &amp; After Photos</a></li> -->
</ul>
</div>
<!--menu -->

</div>
</div>
</section>
<!--/Navigation --><!--/Navigation --> 
<!--/Navigation --><!--/Navigation -->
		


<!-- department-menu -->
<!--sidebar -->
<!--sidebar -->

<!--/sidebar --><!--/sidebar -->
<!--/department-menu --> 

 
 <!-- go-top-->
<!--<div id='fixed-bar'><a class='go-top' href='#' title='back to top'>Back to Top</a> </div> -->
<!-- /go-top-->



   
   
   
   
   


<!--counter -->
<script src="../assets/js/counter/waypoints.min.js"></script> 
<script src="../assets/js/counter/jquery.counterup.min.js"></script> 
<script>
    jQuery(document).ready(function( $ ) {
        $('.counter').counterUp({
            delay: 10,
            time: 1000
        });
    });
</script>


	

<!--parallax -->
<script src="../assets/js/parallax/jquery.min.js"></script>
<script src="../assets/js/parallax/jarallax.js"></script>
<script >
         /* init Jarallax */     
	$('.jarallax').jarallax({
	speed: 0.5,
	imgWidth: 1366,
	imgHeight: 768
})
         
</script>



<!--search script -->
<script src="../assets/js/search/classie.js" ></script>
<script src="../assets/js/search/uisearch.js" ></script>
<script>
new UISearch( document.getElementById( 'sb-search' ) );
</script>


	

<!--slider-->
<!--<script src="js/slider/jquery-1.js"></script> -->
<script src="../assets/js/slider/bootstrap.js"></script>


<!--menu js -->
<!--<script src='js/hamburger/jquery.min.js'></script> -->
<script  src="../assets/js/hamburger/menu.js"></script>

	

<!--before after js -->
<script src="../assets/js/beforeafter/cocoen.min.js"></script>
<script>
	document.addEventListener('DOMContentLoaded', function(){
	new Cocoen();
	});
	
</script>

<!--Accordian -->
<script  src="../assets/js/accordian/jquery-1.10.1.min.js"></script>
<script  src="../assets/js/accordian/smk-accordion.js"></script>
<script >
		jQuery(document).ready(function($){

			$(".accordion_example1").smk_Accordion();

	
		});
	</script>

<!--tabs -->
<script src="../assets/js/tabs/jquery.min.js"></script>
<script src="../assets/js/tabs/SimpleTabs.js" ></script>	

<!--sidebar js -->
<!--<script src="js/sidebar/jquery-2.2.3.min.js" defer></script>  -->
<script src="../assets/js/sidebar/sidebar.js" defer></script>

   <!--scroller -->
<!--<script src="js/carousel/jquery-1.9.1.min.js"></script>  -->
<script src="../assets/js/carousel/owl.carousel.js"></script>
<script src="../assets/js/carousel/owl.js"></script>	

<!-- datepicker -->
<script src="../../code.jquery.com/ui/1.9.2/jquery-ui.min.js"
  integrity="sha256-eEa1kEtgK9ZL6h60VXwDsJ2rxYCwfxi40VZ9E0XwoEA="
  crossorigin="anonymous"></script>
<!-- <script  src="https://code.jquery.com/ui/1.9.2/jquery-ui.js"></script> -->
<link rel="stylesheet"  href="../../code.jquery.com/ui/1.9.2/themes/base/jquery-ui.css">
<script >//<![CDATA[
$(function(){
$("#txt_appdate").datepicker({
numberOfMonths: 1,
dateFormat: 'dd/mm/yy',
minDate: +1,

onSelect: function () {
$('#DepartDate').datepicker('option', {
minDate: $(this).datepicker('getDate')
});
}
});
$("#txt_appdate1").datepicker({
numberOfMonths: 1,
dateFormat: 'dd/mm/yy',
minDate: 0,

onSelect: function () {
$('#DepartDate').datepicker('option', {
minDate: $(this).datepicker('getDate')
});
}
});

});
$(function() {
$( "#txt_dob" ).datepicker({
dateFormat: 'dd/mm/yy',
changeMonth: true,
changeYear: true,
yearRange: '-100:+0'
});
});



/*$(function(){
$( "#txt_dob" ).datepicker();
//Pass the user selected date format
$( "#format" ).change(function() {
$( "#txt_dob" ).datepicker( "option", "dateFormat", $(this).val() );
});
});*/

</script>

<!-- BACK TO TOP -->
<script  src="../assets/js/backtotop/fixedbar.js"></script> 

<!--slideout tab -->

<script src="../assets/js/slidetab/jquery.tabSlideOut.v1.3.js"></script>

<script >
$(document).ready(function()
{
$("#department").change(function()
{
//alert('Hai');
var id=$(this).val();

var dataString = 'id='+ id;
$.ajax
({
type: "POST",
url: "https://www.specialistshospital.com/ajaxapp.php",
data: dataString,
cache: false,
success: function(html)
{
//alert(html);
$("#select_doctor").html(html);
}
});

});

});
</script>

<!-- sticky js -->
<script>
    function init() {
        window.addEventListener('scroll', function(e){
            var distanceY = window.pageYOffset || document.documentElement.scrollTop,
                shrinkOn = 40,
                header = document.querySelector("header");
            if (distanceY > shrinkOn) {
                classie.add(header,"smaller");
            } else {
                if (classie.has(header,"smaller")) {
                    classie.remove(header,"smaller");
                }
            }
        });
    }
    window.onload = init();

    function recaptchaCallbackCareer() 
  {
    var bookbutton = document.getElementById("Submit_career_btn");
    document.getElementById('Submit_career_btn').disabled = false;
  }

    function recaptchaCallbackContact() 
  {
    var bookbutton = document.getElementById("Submit_Contact_Enquiry_btn");
    document.getElementById('Submit_Contact_Enquiry_btn').disabled = false;
  }

    function recaptchaCallbackPopup() 
  {
    var bookbutton = document.getElementById("Submit_apppopup_btn");
    document.getElementById('Submit_apppopup_btn').disabled = false;
  }

    function recaptchaCallbackExpert() 
  {
    var bookbutton = document.getElementById("Submit_Expert_btn");
    document.getElementById('Submit_Expert_btn').disabled = false;
  }

  $(document).ready(function(){
        $( "#email,#name,#txt_dob,#phone,#txt_appdate,#message,#txt_appdate,#address,#qualification " ).on( "copy cut paste drop", function() {
                return false;
        });
  });

</script>



<?php //include "inc/navbar.php"; ?>
<!--/Navigation --><!--/Navigation -->



<!--sidebar -->
<!--sidebar -->
<?php include "../inc/sidebar.php"; ?>
<!--/sidebar --><!--/sidebar -->




 <!-- go-top-->
<?php //include "inc/gotoup.php"; ?>
<!-- /go-top-->

<!-- popup form -->
<!-- popup form -->
<!--counter -->
<?php //include "inc/popup.php" ; ?>
<?php //include "inc/script.php"; ?>
<?php //include "../inc/bookappoinment.php"; ?>
<?php include "../inc/footer.php"; ?>
   
   
   
   
   
   
   

