	    <?php include "includefiles/header.php"; ?>

<style>

 @media only screen and (max-width: 700px) {
	 
	.banner1 {
 
    /*  background-image: url(uploads/banners/drtreatment.jpg);*/
	  
	   margin-top:10%;
	margin-left:0%;
	margin-right:0%;
      width:100%;height:75vh!important;float:left;position:relative;background-position:center;background-size:cover;background-repeat:no-repeat; padding:1px;
    
  }
  
 }
 /* for mobile  */

  .banner1 {
     
      background-image: url(uploads/pagebanner/pilonidalsinus.webp);
  }
</style>
</head>


<?php include "includefiles/header2.php";?>




<!--inner-banner--> 
<div class="inner-banner jarallax banner1">

</div>
<!--/inner-banner--> 


<!--START INNER CONTENT -->
<section class="pad">
<div class="main">
  
<!--row -->
<div class="row">
  <div class="col-sm-12">
    <div class="col-sm-5" style="margin-left:-20px!important;">
<center><h2 class="page-title">PILONIDAL SINUS</h2> </center>
     <center> <img src="uploads/images/Pilonidal-Sinus.webp" style="margin-top: 5%;" width="300px" height="300"> </center>
  </div>
    <div class="col-sm-7" style="margin-top: 5%;">
<div class="margin-bottom">
<!-- Accordion begin --><div class="accordion_example1" style="margin-left:-20px!important;">	
	<!-- item1 -->
	<!-- item2 --><div class="accordion_in"><div class="acc_head">What Is It</div><div class="acc_content"><p></p><h3 class="subheading text-green">Pilonidal Sinus</h3>
    <ul class="list">
      <li>Pilonidal' means nest of hairs.</li>
      <li>A pilonidal sinus is a sinus which contains a tuft of hairs.</li>
      <li>These sinus are found in the skin covering the last part of spine</li>
      <li>It also called as "Jeep- Bottom " because it is very common in Jeep drivers.</li>
      
  </ul> 
   </div></div><!-- item2 -->
	<!-- item3 --><div class="accordion_in"><div class="acc_head">Symptoms</div><div class="acc_content"><p></p><h3 class="subheading text-green">Symptoms</h3>
    <ul class="list">
      <li>External sinus opening seen at the base of spine between the buttocks</li>
      <li>Pus discharge</li>
      <li>History of recurrent abscess at same site.</li>
      <li>Fever</li>
    </ul>  </div></div><!-- item3 -->
				   
				   
				   
	</div><!-- Accordion end -->
</div>
</div>


  </div>
</div>





</div>
</section>
<!--/INNER CONTENT END -->


 
   
  <!-- footer -->


     <!-- footer -->

<?php include "includefiles/footer.php"; ?>
<!--/footer --> 

<!-- open/close --> 
<!--Navigation -->
<!-- open/close -->
<!--Navigation -->
<?php include "includefiles/navbar.php"; ?>
<!--/Navigation --><!--/Navigation --> 

<!-- department-menu --> 
<!--sidebar -->
<!--sidebar -->
<?php include "includefiles/sidebar.php"; ?>
<!--/sidebar --><!--/sidebar --> 
<!--/department-menu --> 

<!-- go-top-->
<?php include "includefiles/gotoup.php"; ?>
<!-- /go-top-->



<?php include "includefiles/scriptall.php";?>

</body>

</html> 
   
   
   
   
   
   



   
   
   

