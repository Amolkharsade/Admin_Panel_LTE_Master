	    <?php include "includefiles/header.php"; ?>

<style>

     @media only screen and (max-width: 700px) {
	 
	.banner1 {
    
	   margin-top:12%;
	margin-left:0%;
	margin-right:0%;
      width:100%;height:60vh!important;float:left;position:relative;background-position:center;background-size:cover;background-repeat:no-repeat; padding:1px;
    
  }
  
 }
 /* for mobile  */


  .banner1 {
    
      background-image: url(uploads/pagebanner/piles.webp);
  }
</style>
</head>


<?php include "includefiles/header2.php";?>




<!--inner-banner--> 
<div class="inner-banner jarallax banner1">

</div>
<!--/inner-banner--> 


<!--START INNER CONTENT -->
<section class="pad" >

<div class="main" >

<!--<center><h3 class="title"> <strong>Piles Treatment</strong><br></h3></center>-->

<!--<center><h4 class="bordered">
<span><a href="index.php">Home</a></span> - Piles </h4></center>-->


 	<!--row -->
<div class="row">
  <div class="col-sm-12">
    <div class="col-sm-5" style="margin-left:-20px!important;">
      <center><h2 class="page-title">PILES </h2></center>
     <center> <img src="uploads/images/Piles.webp" style="margin-top: 5%;" width="300px" height="300" > </center>
  </div>
    <div class="col-sm-7"  style="margin-top:5%;">
	<!--row -->
<div class="row">
<div class="margin-bottom">
<!-- Accordion begin --><div class="accordion_example1" style="margin-left:-20px!important;">	
	<!-- item1 --><div class="accordion_in "><div class="acc_head">What Is It</div><div class="acc_content"><h3 class="subheading text-green">Piles</h3><p>Hemorrhoids (HEM-uh-roids), also called piles, are swollen and inflamed veins in your anus and lower rectum. Hemorrhoids may result from straining during bowel movements or from the increased pressure on these veins during pregnancy. Hemorrhoids may be located inside the anus (internal hemorrhoids), or they may develop under the skin around the anus (external hemorrhoids).</p><!--<ul class="list"><li>Register your name either by phone, mail or fax</li><li>Mention the date of arrival</li><li>Get admitted in the morning</li><li>Consultation and check-up</li><li>Investigations</li><li>Counselling and advice</li><li>Discharge in the evening</li></ul><h3 class="subheading text-green">Our Executive Check-up Helps to Detect</h3><ul class="list"><li>Hypertension</li><li>Diabetes</li><li>Lung Diseases</li><li>Liver Diseases</li><li>Kidney Diseases</li><li>Mass in Abdomen</li><li>Prostate cancer</li> </ul>--></div></div><!-- item1 -->
	<!-- item2 --><div class="accordion_in"><div class="acc_head">Symptoms</div><div class="acc_content"><p></p><h3 class="subheading text-green">Symptoms</h3><ul class="list"><li>Bleeding (Splash in the pan).</li><li>No pain.</li><li>Prolaps of mass through anus.</li><li>Discharge of mucous ( Sticky fluid).</li><li>Itching.</li></ul>  </div></div><!-- item2 -->
	<!-- item3 --><div class="accordion_in"><div class="acc_head">Causes</div><div class="acc_content"><p></p><h3 class="subheading text-green">Causes</h3><ul class="list"><li>Constipation.</li><li>Straining during, passing stool.</li><li>Familial or Genetic or Hereditary.</li><li>Pregnancy.</li><li>Cancer.</li><li>Obesity. </li><li>Continues sitting or standing work position. </li><li> Continues Lifting heavy weights.</li></ul>  </div></div><!-- item3 -->
	<!-- item4 --><div class="accordion_in"><div class="acc_head">Diagnosis</div><div class="acc_content"><p></p><h3 class="subheading text-green">Diagnosis</h3><ul class="list"><li>Per rectal digital examination.</li><li>Proctoscopy.</li><li>Sigmoidoscopy.</li></ul>  </div></div><!-- item4 -->
	<!-- item5 --><div class="accordion_in"><div class="acc_head">Types</div><div class="acc_content"><h3 class="subheading text-green">Types</h3><ul class="list"><li>External.</li><li>Internal.</li><li>Interno-external.</li></ul><h3 class="subheading text-green">First degree piles.</h3> <p> No mass protruding from the anus(Only bleeding).</p>
	               <h3 class="subheading text-green">Second degree piles.</h3> <p> Piles mass protrudes out from the anus but returns spontaneously after passing stood.</p>
				   <h3 class="subheading text-green">Third degree piles.</h3> <p> Piles mass protrudes out from the anus but some force (with finger) require to push back.</p>
				   <h3 class="subheading text-green">Fourth Degree Piles.</h3> <p> Piles mass remains protruded out of anus permanently.</p>
				   </div></div><!-- item 5-->
  <!-- item6 --><div class="accordion_in"><div class="acc_head">Complication</div><div class="acc_content"><p></p><h3 class="subheading text-green">Complication</h3><ul class="list"><li>Anemia(Decrease in hemoglobin (Hb) due to loss of blood.).</li><li>Pain</li><li>Infection.</li><li>Thrombosis.</li></ul>  </div></div><!-- item6 -->				   
				   
				   
	</div><!-- Accordion end -->
</div>
</div>


  </div>
</div>





</div>
</section>
<!--/INNER CONTENT END -->


 
   
  <!-- footer -->


     <!-- footer -->

<?php include "includefiles/footer.php"; ?>
<!--/footer --> 

<!-- open/close --> 
<!--Navigation -->
<!-- open/close -->
<!--Navigation -->
<?php include "includefiles/navbar.php"; ?>
<!--/Navigation --><!--/Navigation --> 

<!-- department-menu --> 
<!--sidebar -->
<!--sidebar -->
<?php include "includefiles/sidebar.php"; ?>
<!--/sidebar --><!--/sidebar --> 
<!--/department-menu --> 

<!-- go-top-->
<?php include "includefiles/gotoup.php"; ?>
<!-- /go-top-->

<!-- /slide-out-div-->
<?php include "includefiles/scriptall.php";?>
</body>

</html> 
   
   
   
   
   
   



   
   
   

