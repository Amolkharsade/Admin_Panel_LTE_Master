	    <?php include "includefiles/header.php"; ?>

<style>

   @media only screen and (max-width: 700px) {
	 
	.banner1 {
    
     /* background-image: url(uploads/banners/drtreatment.jpg);*/
	  
	   margin-top:10%;
	margin-left:0%;
	margin-right:0%;
      width:100%;height:75vh!important;float:left;position:relative;background-position:center;background-size:cover;background-repeat:no-repeat; padding:1px;
    
  }
  
 }
 /* for mobile  */
  
  

  .banner1 {
      
      background-image: url(uploads/pagebanner/constipation01.webp);
  }
</style>
</head>


<?php include "includefiles/header2.php";?>




<!--inner-banner--> 
<div class="inner-banner jarallax banner1">

</div>
<!--/inner-banner--> 


<!--START INNER CONTENT -->
<section class="pad">
<div class="main">
    
  

<!--row -->
<div class="row">
  <div class="col-sm-12">
    <div class="col-sm-5" style="margin-left:-20px!important;">
<center><h2 class="page-title">CONSTIPATION</h2>
      <img src="uploads/images/Constipation.webp" style="margin-top: 5%;" width="300px" height="300"></center>
  </div>
    <div class="col-sm-7" style="margin-top: 5%;">
<div class="margin-bottom">
<!-- Accordion begin --><div class="accordion_example1" style="margin-left:-18px!important;">	
	<!-- item1 --><div class="accordion_in "><div class="acc_head">What Is It</div><div class="acc_content"><h3 class="subheading text-green">Constipation</h3><p>Constipation means infrequent stool, hard Stool, difficulty in passing stool (straining) or a sence of incomplete emptying after a bowel movement.</p></div></div><!-- item1 -->
	<!-- item2 --><div class="accordion_in"><div class="acc_head">Causes</div><div class="acc_content"><p></p><h3 class="subheading text-green">Causes</h3>
    <ul class="list">
      <li>Fibreless diet.</li>
      <li>Faulty eating habits</li>
      <li>Fast food</li>
      <li>Fast life</li>
      <li>Anal Fissure</li>
      <li>Piles (Haemorrhoids)</li>
      <li>Anal Stenosis</li>
      <li>Perianal abscess</li>
      <li>Amoebiasis</li>
      <li>chron's disease</li>
      <li>IBS</li>
      <li>Diabetis</li>
      <li>Pregnancy</li>
      <li>psychiatric disorders.</li>
      <li>Regular use of stimulent laxative</li>
      <li>Less fluid intake</li>
  </ul> 
   </div></div><!-- item2 -->
	<!-- item3 --><div class="accordion_in"><div class="acc_head">Invetigation</div><div class="acc_content"><p></p><h3 class="subheading text-green">Causes</h3><ul class="list"><li>Per-rectal digital examination.</li><li>Proctoscopy</li><li>Sigmoidoscopy</li><li>Barium enema.</li></ul>  </div></div><!-- item3 -->
				   
				   
				   
	</div><!-- Accordion end -->
</div>
</div>


  </div>
</div>





</div>
</section>
<!--/INNER CONTENT END -->


 
   
  <!-- footer -->


     <!-- footer -->

<?php include "includefiles/footer.php"; ?>
<!--/footer --> 


<?php include "includefiles/navbar.php"; ?>
<!--/Navigation --><!--/Navigation --> 


<?php include "includefiles/sidebar.php"; ?>
<!--/sidebar --><!--/sidebar --> 
<!--/department-menu --> 

<!-- go-top-->
<?php include "includefiles/gotoup.php"; ?>
<!-- /go-top-->



<?php include "includefiles/scriptall.php";?>


</body>

</html> 
   
   
   
   
   
   



   
   
   

