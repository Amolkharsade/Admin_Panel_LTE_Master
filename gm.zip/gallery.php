	   <?php include "includefiles/header.php"; ?>

<style>

 @media only screen and (max-width: 700px) {
	 
	.banner1 {
      
	  
	   margin-top:12%;
	margin-left:0%;
	margin-right:0%;
      width:100%;height:75vh!important;float:left;position:relative;background-position:center;background-size:cover;background-repeat:no-repeat; padding:1px;
    
  }
  
 }
 /* for mobile  */
 
  .banner1 {
      background-image: url(uploads/pagebanner/news.webp);
  }
</style>
</head>


<?php include "includefiles/header2.php";?>





<!--inner-banner--> 
<div class="inner-banner jarallax banner1">
</div>
<!--/inner-banner--> 




<!--START INNER CONTENT -->
<section class="pad">
<div class="main">
<h2 class="page-title">Our Articles</h2>
<!--<h2 class="breadcrumb">
<a href="index.php"><span>Home</span></a> - Articles</h2>-->



<!-- Our Treatment -->

<!--<section class="pad">
<div class="main">
<h2 class="page-title"> Our Treatments</h2>
<h2 class="breadcrumb"></h2> -->
<div class="rows">

<div class="margin-bottom">
<div class="row">
	<div class="col-sm-12">
		<div class="col-sm-4">
<div class="courses"><p><img src="uploads/news/media-2.webp" alt="media_2" class="fullwidth"></p>
<a href="Injection_Therapy.php"><h2 class="subheading text-green text-center cus-h"></h2></a>


</div>
</div>

<div class="col-sm-4">
<div class=" courses"><p><img src="uploads/news/media-3.webp" alt="media 4" class="fullwidth"></p>
<a href="suton.php"><h2 class="subheading text-green text-center cus-h"></h2></a>
</div>
</div>

<div class="col-sm-4">
<div class="courses"><p><img src="uploads/news/media-4.webp" alt="news 4" class="fullwidth"></p>
<a href="Battons_Brand.php"><h2 class="subheading text-green text-center cus-h"></h2></a>
</div>
</div>

</div>
</div>
<!--<br>-->
<div class="row">
	<div class="col-sm-12">
		<div class="col-sm-4">
<div class="courses"><p><img src="uploads/news/media-6.webp" alt="news 6" class="fullwidth"></p>
<a href="infrared_coagulation.php"><h2 class="subheading text-green text-center cus-h"> </h2></a>

</div>
</div>webp

<div class="col-sm-4">
<div class=" courses"><p><img src="uploads/news/media-8.webp" alt="news 9" class="fullwidth"></p>
<a href="stapler_surgery.php"><h2 class="subheading text-green text-center cus-h"></h2></a>
</div>
</div>

<div class="col-sm-4">
<div class="courses"><p><img src="uploads/news/media-9.webp" alt="news 9." class="fullwidth"></p>

<a href="#"><h2 class="subheading text-green text-center cus-h"></h2></a>
</div>
</div>

</div>
</div>


<!--3 -->
<div class="row">
	<div class="col-sm-12">
		<div class="col-sm-4">
<div class="courses"><p><img src="uploads/news/media-10.webp" alt="news 6" class="fullwidth"></p>
<a href="infrared_coagulation.php"><h2 class="subheading text-green text-center cus-h"> </h2></a>

</div>
</div>

<div class="col-sm-4">
<div class=" courses"><p><img src="uploads/news/media-11.webp" alt="news 9" class="fullwidth"></p>
<a href="stapler_surgery.php"><h2 class="subheading text-green text-center cus-h"></h2></a>
</div>
</div>

<div class="col-sm-4">
<div class="courses"><p><img src="uploads/news/media-12.webp" alt="news 9." class="fullwidth"></p>

<a href="#"><h2 class="subheading text-green text-center cus-h"></h2></a>
</div>
</div>

</div>
</div>
<!--4-->

<div class="row">
	<div class="col-sm-12">
		<div class="col-sm-4">
<div class="courses"><p><img src="uploads/news/media-13.webp" alt="news 6" class="fullwidth"></p>
<a href="infrared_coagulation.php"><h2 class="subheading text-green text-center cus-h"> </h2></a>

</div>
</div>

<div class="col-sm-4">
<div class=" courses"><p><img src="uploads/news/media-14.webp" alt="news 9" class="fullwidth"></p>
<a href="stapler_surgery.php"><h2 class="subheading text-green text-center cus-h"></h2></a>
</div>
</div>

<div class="col-sm-4">
<div class="courses"><p><img src="uploads/news/media-15.webp" alt="news 9." class="fullwidth"></p>

<a href="#"><h2 class="subheading text-green text-center cus-h"></h2></a>
</div>
</div>

</div>
</div>

<!--5-->
</div>
</div>
</div>
</section>



<!-- End Treatment -->
























</div>
</section>
<!--/INNER CONTENT END -->







<!-- End Treatment -->



  <!-- footer -->

 <?php include "includefiles/footer.php"; ?>
<!--/footer --> 

<!-- open/close --> 
<!--Navigation -->
<!-- open/close -->
<!--Navigation -->
<?php include "includefiles/navbar.php"; ?>
<!--/Navigation --><!--/Navigation --> 

<!-- department-menu --> 
<!--sidebar -->
<!--sidebar -->
<?php include "includefiles/sidebar.php"; ?>
<!--/sidebar --><!--/sidebar --> 
<!--/department-menu --> 

<!-- go-top-->
<?php include "includefiles/gotoup.php"; ?>
<!-- /go-top-->



<!-- /slide-out-div-->
<script>
function current_pageclick() {
  window.location.assign("gallery.php");
}
</script>

<!-- popup form --> 

<!--counter -->
<script src="assets/js/counter/waypoints.min.js"></script> 
<script src="assets/js/counter/jquery.counterup.min.js"></script> 
<script>
    jQuery(document).ready(function( $ ) {
        $('.counter').counterUp({
            delay: 10,
            time: 1000
        });
    });
</script> 

<!--parallax --> 
<script src="assets/js/parallax/jquery.min.js"></script> 
<script src="assets/js/parallax/jarallax.js"></script> 
<script >
         /* init Jarallax */     
	$('.jarallax').jarallax({
	speed: 0.5,
	imgWidth: 1366,
	imgHeight: 768
})
         
</script> 

<!--search script --> 
<script src="assets/js/search/classie.js" ></script> 
<script src="assets/js/search/uisearch.js" ></script> 
<script>
new UISearch( document.getElementById( 'sb-search' ) );
</script> 

<!--slider--> 
<!--<script src="js/slider/jquery-1.js"></script> --> 
<script src="assets/js/slider/bootstrap.js"></script> 

<!--menu js --> 
<!--<script src='js/hamburger/jquery.min.js'></script> --> 
<script  src="assets/js/hamburger/menu.js"></script> 

<!--before after js --> 
<script src="assets/js/beforeafter/cocoen.min.js"></script> 
<script>
	document.addEventListener('DOMContentLoaded', function(){
	new Cocoen();
	});
	
</script> 

<!--Accordian --> 
<script  src="assets/js/accordian/jquery-1.10.1.min.js"></script> 
<script  src="assets/js/accordian/smk-accordion.js"></script> 
<script >
		jQuery(document).ready(function($){

			$(".accordion_example1").smk_Accordion();

	
		});
	</script> 

<!--tabs --> 
<script src="assets/js/tabs/jquery.min.js"></script> 
<script src="assets/js/tabs/SimpleTabs.js" ></script> 

<!--sidebar js --> 
<!--<script src="js/sidebar/jquery-2.2.3.min.js" defer></script>  --> 
<script src="assets/js/sidebar/sidebar.js" defer></script> 

<!--scroller --> 
<!--<script src="js/carousel/jquery-1.9.1.min.js"></script>  --> 
<script src="assets/js/carousel/owl.carousel.js"></script> 
<script src="assets/js/carousel/owl.js"></script> 

<!-- BACK TO TOP --> 
<script  src="assets/js/backtotop/fixedbar.js"></script> 

<!--slideout tab --> 
<script src="assets/js/slidetab/jquery.tabSlideOut.v1.3.js"></script> 
<script >
$(document).ready(function()
{
  $("#department").change(function()
  {
    //alert('test dep');
    var id=$(this).val();

    var dataString = 'id='+ id;
    $.ajax
    ({
    type: "POST",
    url: "https://goodmorninghospital.blucorsys.com/ajaxapp.php",
    data: dataString,
    cache: false,
    success: function(html)
    {
    //alert(html);
    $("#select_doctor").html(html);
    }
    });

  });

  $("#select_doctor").change(function()
  {
    //alert('test day');
    var obj = [];
    var doc_id=$(this).val();
    var dataString2 = 'doc_id='+ doc_id;
    $.ajax
    ({
        type: "POST",
        url: "https://goodmorninghospital.blucorsys.com/ajaxappday.php",
        data: dataString2,
        cache: false,
        global: false,
        async:false,
        success: function(msg)
        {
                //alert(msg);
                            document.getElementById("hiddendayvalue").value = msg; 
                
        }
    });
                
  });

});
</script> 

<!-- datepicker --> 
<script src="../code.jquery.com/ui/1.9.2/jquery-ui.min.js"></script> 
<link rel="stylesheet"  href="../code.jquery.com/ui/1.9.2/themes/base/jquery-ui.css">
<script >

$(document).ready(function(){
    //var hval=document.getElementById('hiddendayvalue').value;
    //var obj = JSON.parse(hval);
    //alert(obj);
        $("#txt_appdate").datepicker({
        numberOfMonths: 1,
        dateFormat: 'dd/mm/yy',
        minDate: +1,
        beforeShowDay: enabledays       });

    function enabledays(date){
        var day = date.getDay(), Sunday = 0, Monday = 1, Tuesday = 2, Wednesday = 3, Thursday = 4, Friday = 5, Saturday = 6;
        
        var hval = document.getElementById('hiddendayvalue').value;
                
        var enbleDays = hval;

                for (var i = 0; i < enbleDays.length; i++) {
            if (day == enbleDays[i][0]) {
                return [true];
            }
        }
        return [false];                     
        
    }

});

$(function() {
$( "#txt_dob" ).datepicker({
dateFormat: 'dd/mm/yy',
changeMonth: true,
changeYear: true,
yearRange: '-100:+0'
});
});

</script> 

<!-- sticky js -->
<script>
    function init() {
        window.addEventListener('scroll', function(e){
            var distanceY = window.pageYOffset || document.documentElement.scrollTop,
                shrinkOn = 40,
                header = document.querySelector("header");
            if (distanceY > shrinkOn) {
                classie.add(header,"smaller");
            } else {
                if (classie.has(header,"smaller")) {
                    classie.remove(header,"smaller");
                }
            }
        });
    }
    window.onload = init();

    function recaptchaCallbackCareer() 
  {
    var bookbutton = document.getElementById("Submit_career_btn");
    document.getElementById('Submit_career_btn').disabled = false;
  }

    function recaptchaCallbackContact() 
  {
    var bookbutton = document.getElementById("Submit_Contact_Enquiry_btn");
    document.getElementById('Submit_Contact_Enquiry_btn').disabled = false;
  }

    function recaptchaCallbackPopup() 
  {
    var bookbutton = document.getElementById("Submit_apppopup_btn");
    document.getElementById('Submit_apppopup_btn').disabled = false;
  }

    function recaptchaCallbackExpert() 
  {
    var bookbutton = document.getElementById("Submit_Expert_btn");
    document.getElementById('Submit_Expert_btn').disabled = false;
  }

  $(document).ready(function(){
        $( "#email,#name,#txt_dob,#phone,#txt_appdate,#message,#txt_appdate,#address,#qualification,#txtInputcap,#txtInput " ).on( "copy cut paste drop", function() {
                return false;
        });
  });

</script> 
<!-- popup -->
<!--<script type="text/javascript" src="js/mind9a9.js"></script>-->
<script type="text/javascript">
$(window).load(function() {
   setTimeout(function() {
   var count = 9;
       $("#sun-pop").fadeIn("slow");
   $(".sun-div").fadeIn("slow");
   var i = Math.floor(Math.random()*count)+1;
   $(".video"+i).fadeIn("fast");
   }, 1000);
 $(".sun-div, .sun-button, .sun-close, .sun-browse").click(function(e) {
       $("#sun-pop").fadeOut("slow");
   $(".sun-div").fadeOut("slow");
   $("#sun-pop").fadeOut("fast").find("iframe").attr("src", "");
   });
});
</script>

<script src="assets/js/gg-popupform.js"></script> 
<script src="assets/js/gg-captcha.js"></script>


</body>

</html> 
   