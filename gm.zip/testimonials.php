	    <?php include "includefiles/header.php"; ?>

<style>




/* read more start*/

#more {display: none;}

/* read more end*/

 @media only screen and (max-width: 700px) {
	 
	.banner1 {
      
	  
	   margin-top:12%;
	margin-left:0%;
	margin-right:0%;
      width:100%;height:85vh!important;float:left;position:relative;background-position:center;background-size:cover;background-repeat:no-repeat; padding:1px;
    
  }
  
 }
 /* for mobile  */


  .banner1 {
      background-image: url(uploads/pagebanner/happypatient.webp);
     

  */
  }
</style>
</head>


<?php include "includefiles/header2.php";?>
<!--inner-banner--> 
<div class="inner-banner jarallax banner1">

</div>
<!--/inner-banner--> 
<section class="pad">
<div class="main">
<h2 class="page-title">Testimonial</h2>
<!--<h2 class="breadcrumb">
<a href="index.php"><span>Home</span></a> -  Testimonial</h2>-->
<h2 style="text-align:center">What Our Patient Says !!!</h2>
	<!--quote-container -->
	<div class="container">
	    
	    <div>
	    <img src="assets/images/testimonial01.webp"  class="img-rounded" alt="Cinque Terre" width="100%" height="auto" margin-top:-2%>
	    </div><br>
	    <div>
	         <img src="assets/images/testimonial02.webp"  class="img-rounded" alt="Cinque Terre" width="100%" height="auto">
	    </div><br>
	    <div>
	         <img src="assets/images/testimonial03.webp"  class="img-rounded" alt="Cinque Terre" width="100%" height="auto">
	    </div><br>
	    <div>
	         <img src="assets/images/testimonial04.webp"  class="img-rounded" alt="Cinque Terre" width="100%" height="auto">
	    </div><br>
	    <div>
	         <img src="assets/images/testimonial05.webp"  class="img-rounded" alt="Cinque Terre" width="100%" height="auto">
	    </div><br>
	    <div>
	         <img src="assets/images/testimonial06.webp"  class="img-rounded" alt="Cinque Terre" width="100%" height="auto">
	    </div><br>
	    <div>
	         <img src="assets/images/testimonial07.webp"  class="img-rounded" alt="Cinque Terre" width="100%" height="auto">
	    </div><br>
	    <div>
	         <img src="assets/images/testimonial08.webp"  class="img-rounded" alt="Cinque Terre" width="100%" height="auto">
	    </div><br>
	    <div>
	         <img src="assets/images/testimonial09.webp"  class="img-rounded" alt="Cinque Terre" width="100%" height="auto">
	    </div><br>
	    <div>
	         <img src="assets/images/testimonial010.webp"  class="img-rounded" alt="Cinque Terre" width="100%" height="auto">
	    </div><br>
	    <div>
	         <img src="assets/images/testimonial011.webp"  class="img-rounded" alt="Cinque Terre" width="100%" height="auto">
	    </div><br>
	    <div>
	         <img src="assets/images/testimonial012.webp"  class="img-rounded" alt="Cinque Terre" width="100%" height="auto">
	    </div><br>
	    </div>
	<div class="quote-container margin-bottom">
			<!--<img src="assets/images/dummy.jpg" alt="testimonial" >-->
		<p class="quote">
		I am 32 years old male had suffered from anal pain and bleeding since 3 year.After every motion there is a pain bleeding.I could not walk without taking a hot sitz bath. Working in office is very uncomfortable. Long trips in a car were out of question. I tried Ayurvedic, allopathic and homeopathic medicine also but I got relief for few days only. When I was consult to Dr.Bhosale at Dr. Bhosales Piles treatment center They diagnosed my disease as fissure in ano.<!--<span id="dots5">...</span><span id="more5">-->  They given me treatment which is totally painless and discharged me on Next day. Now I am free from pain and bleeding. All thanks to Dr.Bhosale and his loveable staff.
<!--<span class="link"><a href="#" target="_blank">View Video</a></span>-->	<!--<p style="text-align:center""color:green;" onclick="myFunction5()" id="myBtn5"><strong>Read more</strong> </p>-->	</p> 
	<p class="topline dark">
	<span class="name">MR. MANISH JOSHI</span>

	<br>Vimannager<br>(IT ENGG.)<br>Speaking about pain fissure.	</p>
	</div>
	<!--/quote-container -->

		<!--quote-container -->
	<div class="quote-container margin-bottom">
		<!--	<img src="assets/images/dummy.jpg" alt="testimonial" >-->
		<p class="quote">
		I suffered from severe piles since 5 yrs. It got so bad that when I went to toilet, the toilet bowl was dark red from blood and some mass comes out through anus. Finally I had enough and I consult to Dr.Bhosale. who said that I was suffering from internal 2nd degree hemorrhoids. Doctor recommend me Laser with band application.<!--<span id="dots4">...</span><span id="more4">--> They do the procedure in the morning and discharged me at Next day Next day from the procedure my bleeding was stoped. Now I am free from that horrible red dragon.
<!--<span class="link"><a href="#" target="_blank">View Video</a></span>-->	<!--<p style="text-align:center""color:green;" onclick="myFunction4()" id="myBtn4"><strong>Read more</strong> </p>--></p>
	<p class="topline dark">
	<span class="name">MR. ATUL GANDHI</span>
	<br> Dhankawadi<br>
(CIVIL ENGG.)<br> Speaking about piles. 	</p>
	</div>
	<!--/quote-container -->



   
		<!--quote-container -->
	<div class="quote-container margin-bottom">
			<!--<img src="assets/images/dummy.jpg" alt="testimonial" >-->
		<p class="quote">
		I am 45 years old male,from Shivajinagar, suffered from fistula since 12 years. I had operated 3 times for same but in a few days it get reoccurred. 4th time doctor rejected my case and told me that there is chance of incontinence (loss of control on motion) after repeated surgery , Then that surgeon reffered me to Dr. Bhosale for further management.<!--<span id="dots3">...</span><span id="more3">--> Dr.Bhosale adviced me Seton treatment for fistula. I Completed my treatment without any hospital admission and without painful daily dressings. And since one and half year I don’t have any complain about my fistula. Thanks to Seton.
<!--<span class="link"><a href="#" target="_blank">View Video</a></span>--><!--<p style="text-align:center""color:green;" onclick="myFunction3()" id="myBtn3"><strong>Read more</strong> </p>-->	</p>
	<p class="topline dark">
	<span class="name">MR. SHARMA</span>
 <br>
(BUSINESSMAN ,SHIVAJINAGAR)<br> Speaking about fistula. 	</p>
	</div>
	<!--/quote-container -->
	
	<!--quote-container -->
	<div class="quote-container margin-bottom">
			<!--<img src="assets/images/dummy.jpg" alt="testimonial" >-->
		<p class="quote">
		After my delivery I suffered from severe burning and pain after motion and bleeding also. I could not seat to feed my baby. I got Dr. Bhosale’s reference from my colleague. <!--<span id="dots2">...</span><span id="more2">--> I meet Dr. Bhosale and he told me that I was suffering from very common problem in pregnancy and followed by delivery. It was fissure. He given me some medicine and ointment also, I got relief from that pain in a weak and I continued that medicine for few day. And now I am free from pain.
<!--<span class="link"><a href="#" target="_blank">View Video</a></span>--> <!--<p style="text-align:center""color:green;" onclick="myFunction2()" id="myBtn2"><strong>Read more</strong> </p>-->	</p>
	<p class="topline dark">
	<span class="name">MRS. KANCHAN PATIL</span>
 <br> Nigdi<br>
	(HOUSE WIFE)<br> Speaking about fissure. 	</p>
	</div>
	<!--/quote-container -->
	
	<!--quote-container -->
	<div class="quote-container margin-bottom">
			<!--<img src="assets/images/dummy.jpg" alt="testimonial" >-->
		<p class="quote">
		Its mr.shaikh from Lonavala. Since 8 day I felt a small swelling at the opening of my anus. It was very uncomfortable and painful for me. I Consulted one bangali doctor (chanci) from kamshet who told me that you are suffering from very dangerous disease and if you don't operated now you will get suffer from Cancer. That day I can’t slept due to fear. Next day, my friend had given me the address of 'Dr.Bhosale’s Piles Treatment Centre'.  <!--<span id="dots1">...</span><span id="more1">--> When I consulted to doctor he told me it is external thrombased Piles and which is formed due to clotting of blood below the anal skin He given me small short of local anaesthesia and removed the clot with in 2min and without pain also. From same day I am free from pain and swelling and from fake cancer also.
<!--<span class="link"><a href="#" target="_blank">View Video</a></span>--> 	</p>
<!--<button style="text-align:center""color:green;" onclick="myFunction1()" id="myBtn1"><strong>Read more</strong> </button>-->

    
	<p class="topline dark">
	<span class="name">MR. MOHAMMAD SHAIKH</span>
 <br> Lonavala<br>
	(WORKER)<br> Speaking about piles.	</p>
	</div>
	<!--/quote-container -->
	
	
	
	
</div>
</section>
<!--/INNER CONTENT END --> 
   
  <!-- footer -->

<!-- footer -->

<?php include "includefiles/footer.php"; ?>
<!--/footer --> 

<!-- open/close --> 
<!--Navigation -->
<!-- open/close -->
<!--Navigation -->
<?php include "includefiles/navbar.php"; ?>
<!--/Navigation --><!--/Navigation --> 

<!-- department-menu --> 
<!--sidebar -->
<!--sidebar -->
<?php include "includefiles/sidebar.php"; ?>
<!--/sidebar --><!--/sidebar --> 
<!--/department-menu --> 

<!-- go-top-->
<?php include "includefiles/gotoup.php"; ?>
<!-- /go-top-->


 <!-- read more section  5-->
 <script>
function myFunction5() {
  var dots5 = document.getElementById("dots5");
  var moreText5 = document.getElementById("more5");
  var btnText5 = document.getElementById("myBtn5");

  if (dots5.style.display === "none") {
    dots5.style.display = "inline";
    btnText5.innerHTML = "Read more"; 
    moreText5.style.display = "none";
  } else {
    dots5.style.display = "none";
    btnText5.innerHTML = "Read less"; 
    moreText5.style.display = "inline";
  }
}
</script>
 <!-- read more section  5 end-->
 <!-- read more section1 last -->
 <script>
function myFunction1() {
  var dots1 = document.getElementById("dots1");
  var moreText1 = document.getElementById("more1");
  var btnText1 = document.getElementById("myBtn1");

  if (dots1.style.display === "none") {
    dots1.style.display = "inline";
    btnText1.innerHTML = "Read more"; 
    moreText1.style.display = "none";
  } else {
    dots1.style.display = "none";
    btnText1.innerHTML = "Read less"; 
    moreText1.style.display = "inline";
  }
}
</script>
 <!-- read more section  1 last end-->
 
 <!-- read more section 2 last -->
 <script>
function myFunction2() {
  var dots2 = document.getElementById("dots2");
  var moreText2 = document.getElementById("more2");
  var btnText2 = document.getElementById("myBtn2");

  if (dots2.style.display === "none") {
    dots2.style.display = "inline";
    btnText2.innerHTML = "Read more"; 
    moreText2.style.display = "none";
  } else {
    dots2.style.display = "none";
    btnText2.innerHTML = "Read less"; 
    moreText2.style.display = "inline";
  }
}
</script>
 <!-- read more section  2 last end-->
 
 <!-- read more section 3 last -->
 <script>
function myFunction3() {
  var dots3 = document.getElementById("dots3");
  var moreText3 = document.getElementById("more3");
  var btnText3 = document.getElementById("myBtn3");

  if (dots3.style.display === "none") {
    dots3.style.display = "inline";
    btnText3.innerHTML = "Read more"; 
    moreText3.style.display = "none";
  } else {
    dots3.style.display = "none";
    btnText3.innerHTML = "Read less"; 
    moreText3.style.display = "inline";
  }
}
</script>
 <!-- read more section  3 last end-->

<!-- read more section 4 last -->
 <script>
function myFunction4() {
  var dots4 = document.getElementById("dots4");
  var moreText4 = document.getElementById("more4");
  var btnText4 = document.getElementById("myBtn4");

  if (dots4.style.display === "none") {
    dots4.style.display = "inline";
    btnText4.innerHTML = "Read more"; 
    moreText4.style.display = "none";
  } else {
    dots4.style.display = "none";
    btnText4.innerHTML = "Read less"; 
    moreText4.style.display = "inline";
  }
}
</script>
 <!-- read more section  4 last end-->

<!-- /slide-out-div-->
<script>
function current_pageclick() {
  window.location.assign("testimonials.php");
}
</script>

<!-- popup form --> 

<!--counter -->
<script src="assets/js/counter/waypoints.min.js"></script> 
<script src="assets/js/counter/jquery.counterup.min.js"></script> 
<script>
    jQuery(document).ready(function( $ ) {
        $('.counter').counterUp({
            delay: 10,
            time: 1000
        });
    });
</script> 

<!--parallax --> 
<script src="assets/js/parallax/jquery.min.js"></script> 
<script src="assets/js/parallax/jarallax.js"></script> 
<script >
         /* init Jarallax */     
	$('.jarallax').jarallax({
	speed: 0.5,
	imgWidth: 1366,
	imgHeight: 768
})
         
</script> 

<!--search script --> 
<script src="assets/js/search/classie.js" ></script> 
<script src="assets/js/search/uisearch.js" ></script> 
<script>
new UISearch( document.getElementById( 'sb-search' ) );
</script> 

<!--slider--> 
<!--<script src="js/slider/jquery-1.js"></script> --> 
<script src="assets/js/slider/bootstrap.js"></script> 

<!--menu js --> 
<!--<script src='js/hamburger/jquery.min.js'></script> --> 
<script  src="assets/js/hamburger/menu.js"></script> 

<!--before after js --> 
<script src="assets/js/beforeafter/cocoen.min.js"></script> 
<script>
	document.addEventListener('DOMContentLoaded', function(){
	new Cocoen();
	});
	
</script> 

<!--Accordian --> 
<script  src="assets/js/accordian/jquery-1.10.1.min.js"></script> 
<script  src="assets/js/accordian/smk-accordion.js"></script> 
<script >
		jQuery(document).ready(function($){

			$(".accordion_example1").smk_Accordion();

	
		});
	</script> 

<!--tabs --> 
<script src="assets/js/tabs/jquery.min.js"></script> 
<script src="assets/js/tabs/SimpleTabs.js" ></script> 

<!--sidebar js --> 
<!--<script src="js/sidebar/jquery-2.2.3.min.js" defer></script>  --> 
<script src="assets/js/sidebar/sidebar.js" defer></script> 

<!--scroller --> 
<!--<script src="js/carousel/jquery-1.9.1.min.js"></script>  --> 
<script src="assets/js/carousel/owl.carousel.js"></script> 
<script src="assets/js/carousel/owl.js"></script> 

<!-- BACK TO TOP --> 
<script  src="assets/js/backtotop/fixedbar.js"></script> 

<!--slideout tab --> 
<script src="assets/js/slidetab/jquery.tabSlideOut.v1.3.js"></script> 
<script >
$(document).ready(function()
{
  $("#department").change(function()
  {
    //alert('test dep');
    var id=$(this).val();

    var dataString = 'id='+ id;
    $.ajax
    ({
    type: "POST",
    url: "https://goodmorninghospital.blucorsys.com/ajaxapp.php",
    data: dataString,
    cache: false,
    success: function(html)
    {
    //alert(html);
    $("#select_doctor").html(html);
    }
    });

  });

  $("#select_doctor").change(function()
  {
    //alert('test day');
    var obj = [];
    var doc_id=$(this).val();
    var dataString2 = 'doc_id='+ doc_id;
    $.ajax
    ({
        type: "POST",
        url: "https://goodmorninghospital.blucorsys.com/ajaxappday.php",
        data: dataString2,
        cache: false,
        global: false,
        async:false,
        success: function(msg)
        {
                //alert(msg);
                            document.getElementById("hiddendayvalue").value = msg; 
                
        }
    });
                
  });

});
</script> 

<!-- datepicker --> 
<script src="../code.jquery.com/ui/1.9.2/jquery-ui.min.js"></script> 
<link rel="stylesheet"  href="../code.jquery.com/ui/1.9.2/themes/base/jquery-ui.css">
<script >

$(document).ready(function(){
    //var hval=document.getElementById('hiddendayvalue').value;
    //var obj = JSON.parse(hval);
    //alert(obj);
        $("#txt_appdate").datepicker({
        numberOfMonths: 1,
        dateFormat: 'dd/mm/yy',
        minDate: +1,
        beforeShowDay: enabledays       });

    function enabledays(date){
        var day = date.getDay(), Sunday = 0, Monday = 1, Tuesday = 2, Wednesday = 3, Thursday = 4, Friday = 5, Saturday = 6;
        
        var hval = document.getElementById('hiddendayvalue').value;
                
        var enbleDays = hval;

                for (var i = 0; i < enbleDays.length; i++) {
            if (day == enbleDays[i][0]) {
                return [true];
            }
        }
        return [false];                     
        
    }

});

$(function() {
$( "#txt_dob" ).datepicker({
dateFormat: 'dd/mm/yy',
changeMonth: true,
changeYear: true,
yearRange: '-100:+0'
});
});

</script> 

<!-- sticky js -->
<script>
    function init() {
        window.addEventListener('scroll', function(e){
            var distanceY = window.pageYOffset || document.documentElement.scrollTop,
                shrinkOn = 40,
                header = document.querySelector("header");
            if (distanceY > shrinkOn) {
                classie.add(header,"smaller");
            } else {
                if (classie.has(header,"smaller")) {
                    classie.remove(header,"smaller");
                }
            }
        });
    }
    window.onload = init();

    function recaptchaCallbackCareer() 
  {
    var bookbutton = document.getElementById("Submit_career_btn");
    document.getElementById('Submit_career_btn').disabled = false;
  }

    function recaptchaCallbackContact() 
  {
    var bookbutton = document.getElementById("Submit_Contact_Enquiry_btn");
    document.getElementById('Submit_Contact_Enquiry_btn').disabled = false;
  }

    function recaptchaCallbackPopup() 
  {
    var bookbutton = document.getElementById("Submit_apppopup_btn");
    document.getElementById('Submit_apppopup_btn').disabled = false;
  }

    function recaptchaCallbackExpert() 
  {
    var bookbutton = document.getElementById("Submit_Expert_btn");
    document.getElementById('Submit_Expert_btn').disabled = false;
  }

  $(document).ready(function(){
        $( "#email,#name,#txt_dob,#phone,#txt_appdate,#message,#txt_appdate,#address,#qualification,#txtInputcap,#txtInput " ).on( "copy cut paste drop", function() {
                return false;
        });
  });

</script> 
<!-- popup -->
<!--<script type="text/javascript" src="js/mind9a9.js"></script>-->
<script type="text/javascript">
$(window).load(function() {
   setTimeout(function() {
   var count = 9;
       $("#sun-pop").fadeIn("slow");
   $(".sun-div").fadeIn("slow");
   var i = Math.floor(Math.random()*count)+1;
   $(".video"+i).fadeIn("fast");
   }, 1000);
 $(".sun-div, .sun-button, .sun-close, .sun-browse").click(function(e) {
       $("#sun-pop").fadeOut("slow");
   $(".sun-div").fadeOut("slow");
   $("#sun-pop").fadeOut("fast").find("iframe").attr("src", "");
   });
});
</script>

<script src="assets/js/gg-popupform.js"></script> 
<script src="assets/js/gg-captcha.js"></script>






</body>

</html> 
   
   
   
   
   
   

