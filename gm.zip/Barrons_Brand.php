	    <?php include "includefiles/header.php"; ?>

<style>
 @media only screen and (max-width: 700px) {
	 
	.banner1 {
     /* background-image: url(uploads/banners/tratment_image.jpg);*/
	  
	   margin-top:9%;
	margin-left:0%;
	margin-right:0%;
      width:100%;height:75vh!important;float:left;position:relative;background-position:center;background-size:cover;background-repeat:no-repeat; padding:1px;
    
  }
  
 }
 /* for mobile  */


  .banner1 {
   
      background-image: url(uploads/pagebanner/barrons-band.webp);
  }
</style>
</head>


<?php include "includefiles/header2.php";?>




<!--inner-banner--> 
<div class="inner-banner jarallax banner1">

</div>
<!--/inner-banner--> 


<!--START INNER CONTENT -->
<section class="pad">

<div class="main">



 	<!--row -->
<div class="row">
  <div class="col-sm-12">
    <div class="col-sm-5" style="margin-left:-20px!important;">
	
       <h2 class="page-title"><center>BARRON'S BAND</center> </h2>
      <img src="uploads/images/treatment/Barrons_Band.webp" style="margin-top: 5%;">
  </div>
    <div class="col-sm-7" style="margin-top:5%;">
	<!--row -->
<div class="row">
<div class="margin-bottom">
<!-- Accordion begin --><div class="accordion_example1" style="margin-left:-20px!important;">	
	<!-- item1 --><div class="accordion_in "><div class="acc_head">What Is It</div><div class="acc_content"><h3 class="subheading text-green"></h3><p>Barron's band application is a procedure in which a small imported band is applied at the base of piles with the help of piles gun. It will stop blood supply of piles mass and piles shrivel and die within 2-5 day. It is most successful treatment for Piles.</p></div></div><!-- item1 -->
	<!-- item2 --><div class="accordion_in"><div class="acc_head">Indications</div><div class="acc_content"><p></p><h3 class="subheading text-green"></h3><ul class="list"><li>Internal 2nd degree piles.</li><li>Internal 3rd degree piles (Early stage).</li></ul>  </div></div><!-- item2 -->
	<!-- item3 --><div class="accordion_in"><div class="acc_head">Benefits</div><div class="acc_content"><p></p><h3 class="subheading text-green"></h3><ul class="list"><li>No cut -No bleeding.</li><li>Virtually painless.</li><li>No incontinence (No loss of control on motion).</li><li>Symptoms will release within 3-4 days.</li><li>No Hospitalization require.</li><li>Fast recovery. </li> <li>No hospitalization require. </li></ul>  </div></div><!-- item3 -->
				   
				   
				   
	</div><!-- Accordion end -->
</div>
</div>


  </div>
</div>





</div>
</section>
<!--/INNER CONTENT END -->


 
   
  <!-- footer -->


     <!-- footer -->

<?php include "includefiles/footer.php"; ?>
<!--/footer --> 

<!-- open/close --> 
<!--Navigation -->
<!-- open/close -->
<!--Navigation -->
<?php include "includefiles/navbar.php"; ?>
<!--/Navigation --><!--/Navigation --> 

<!-- department-menu --> 
<!--sidebar -->
<!--sidebar -->
<?php include "includefiles/sidebar.php"; ?>
<!--/sidebar --><!--/sidebar --> 
<!--/department-menu --> 

<!-- go-top-->
<?php include "includefiles/gotoup.php"; ?>
<!-- /go-top-->


<script>
function current_pageclick() {
  window.location.assign("Barrons_Brand.php");
}
</script>

<!-- popup form --> 

<!--counter -->

<?php include "includefiles/scriptall.php";?>

</body>

</html> 
   
   
   
   
   
   



   
   
   

