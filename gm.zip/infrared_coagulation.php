	    <?php include "includefiles/header.php"; ?>

<style>

 @media only screen and (max-width: 700px) {
	 
	.banner1 {
     /* background-image: url(uploads/banners/tratment_image.jpg);*/
	  
	   margin-top:9%;
	margin-left:0%;
	margin-right:0%;
      width:100%;height:75vh!important;float:left;position:relative;background-position:center;background-size:cover;background-repeat:no-repeat; padding:1px;
    
  }
  
 }
 /* for mobile  */

  .banner1 {
      background-image: url(uploads/pagebanner/infrared.webp);
  }
</style>
</head>


<?php include "includefiles/header2.php";?>




<!--inner-banner--> 
<div class="inner-banner jarallax banner1">

</div>
<!--/inner-banner--> 


<!--START INNER CONTENT -->
<section class="pad">
<div class="main">
    

<div class="row">
  <div class="col-sm-12">
    <div class="col-sm-5" style="margin-left:-20px!important;">
<h2 class="page-title">INFRARED COAGULATION </h2>
      <img src="uploads/images/treatment/Infrared_Coagulation_Therapy.webp"  style="margin-top:5%;">
  </div>
    <div class="col-sm-7" style="margin-top: 5%;">
<div class="margin-bottom">
<!-- Accordion begin --><div class="accordion_example1" style="margin-left:-20px!important;">	
	<!-- item1 -->
	<!-- item2 --><div class="accordion_in active">
    <div class="acc_head">What Is It</div><div class="acc_content "><h3 class="subheading text-green">Infrared Coagulation</h3>
    IRC is a procedure in which the piles mass is Coagulated, with the help of infra red irradiation with a specially designed IRC instrument.
   </div></div><!-- item2 -->
	<!-- item3 --><div class="accordion_in"><div class="acc_head">Indications</div><div class="acc_content"><h3 class="subheading text-green">Indications</h3>
    <ul class="list">
      <li>Internal 1st degree bleeding piles.</li>
      
      
    </ul>  </div></div><!-- item3 -->
				  <!-- item4 --><div class="accordion_in"><div class="acc_head">Benifits</div><div class="acc_content"><h3 class="subheading text-green">Benifits</h3>
    <ul class="list">
      <li>Non -surgical procedure</li>
       <li>Virtually painless</li>
        <li>Can be done in OPD</li>
      
    </ul>  </div></div><!-- item4 --> 
				   
				   
	</div><!-- Accordion end -->
</div>
</div>


  </div>
</div>





</div>
</section>
<!--/INNER CONTENT END -->


 
   
  <!-- footer -->


     <!-- footer -->

<?php include "includefiles/footer.php"; ?>
<!--/footer --> 

<!-- open/close --> 
<!--Navigation -->
<!-- open/close -->
<!--Navigation -->
<?php include "includefiles/navbar.php"; ?>
<!--/Navigation --><!--/Navigation --> 

<!-- department-menu --> 
<!--sidebar -->
<!--sidebar -->
<?php include "includefiles/sidebar.php"; ?>
<!--/sidebar --><!--/sidebar --> 
<!--/department-menu --> 

<!-- go-top-->
<?php include "includefiles/gotoup.php"; ?>
<!-- /go-top-->



<?php include "includefiles/scriptall.php";?>

</body>

</html> 
   
   
   
   
   
   



   
   
   

