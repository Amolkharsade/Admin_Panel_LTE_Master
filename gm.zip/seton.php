	    <?php include "includefiles/header.php"; ?>

<style>
 @media only screen and (max-width: 700px) {
	 
	.banner1 {
    
	  
	   margin-top:10%;
	margin-left:0%;
	margin-right:0%;
      width:100%;height:75vh!important;float:left;position:relative;background-position:center;background-size:cover;background-repeat:no-repeat; padding:1px;
    
  }
  
 }
 /* for mobile  */


  .banner1 {
      /*background-image: url(uploads/banners/tratment_image.jpg);*/
      background-image: url(uploads/pagebanner/seton.webp);
  }
</style>
</head>


<?php include "includefiles/header2.php";?>




<!--inner-banner--> 
<div class="inner-banner jarallax banner1">

</div>
<!--/inner-banner--> 


<!--START INNER CONTENT -->
<section class="pad">

<div class="main">

 	<!--row -->
<div class="row">
  <div class="col-sm-12">
    <div class="col-sm-5" style="margin-left:-20px!important;">
     <h2 class="page-title">SETON</h2>
      <img src="uploads/images/treatment/soton_therapy.webp" style="margin-top: 5%;" width="300px" height="300">
  </div>
    <div class="col-sm-7" style="margin-top:5%;">
	<!--row -->
<div class="row">
<div class="margin-bottom">
<!-- Accordion begin --><div class="accordion_example1" style="margin-left:-22px!important;">	
	<!-- item1 --><div class="accordion_in "><div class="acc_head">What Is It</div><div class="acc_content"><h3 class="subheading text-green"></h3><p>It is specially design treatment for fistula in ano. It is WHO approved procedure and many clinical trials has done in India,Shrilanka and Japan.It is most successfull treatment for fistula.</p></div></div><!-- item1 -->
	<!-- item2 --><div class="accordion_in"><div class="acc_head">Indications</div><div class="acc_content"><p></p><h3 class="subheading text-green"></h3><ul class="list"><li>Low anal fistula.</li><li>High anal fistula.</li><li>Multiple Fistula in ano .</li></ul>  </div></div><!-- item2 -->
	<!-- item3 --><div class="accordion_in"><div class="acc_head">Benefits</div><div class="acc_content"><p></p><h3 class="subheading text-green"></h3><ul class="list"><li>Non -surgical procedure.</li><li>No cut- no pain -no bleeding.</li><li>No incontinence (no loss of control on motion).</li><li>No recurrence.</li><li>No daily dressing require.</li><li>No hospitalization require. </li> </ul>  </div></div><!-- item3 -->
				   
				   
				   
	</div><!-- Accordion end -->
</div>
</div>


  </div>
</div>





</div>
</section>
<!--/INNER CONTENT END -->


 
   
  <!-- footer -->


     <!-- footer -->

<?php include "includefiles/footer.php"; ?>
<!--/footer --> 

<!-- open/close --> 
<!--Navigation -->
<!-- open/close -->
<!--Navigation -->
<?php include "includefiles/navbar.php"; ?>
<!--/Navigation --><!--/Navigation --> 

<!-- department-menu --> 
<!--sidebar -->
<!--sidebar -->
<?php include "includefiles/sidebar.php"; ?>
<!--/sidebar --><!--/sidebar --> 
<!--/department-menu --> 

<!-- go-top-->
<?php include "includefiles/gotoup.php"; ?>
<!-- /go-top-->



<?php include "includefiles/scriptall.php";?>

</body>

</html> 
   
   
   
   
   
   



   
   
   

