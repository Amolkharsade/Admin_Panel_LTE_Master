<!--sidebar -->
<!--sidebar -->
<div class="sidebar" id="sidebar-right" >
<div class="close">
<a href="index.php" id="sidebar-close" class="btn-close">X</a>
</div>

<!-- parent -->
<div class="parent">
<div class="child">

<h1>Excellence in<br>
<span>Super Speciality Hospital Care</span></h1>

<div class="navcol">
	<ul>
		<li><a href="piles_details.php">Piles</a></li>	
		<li><a href="Fissure_details.php">Fissure</a></li>	
		<li><a href="Fistula_details.php">Fistula</a></li>	
		<li><a href="Abscess_details.php">Abscess</a></li>	
			
			
			
		<!--<li><a href="departments/general-medicine.html">General Medicine</a></li>-->
			
		<!--<li><a href="departments/paediatrics.html">Paediatrics</a></li>	
		<li><a href="departments/oncology.html">Oncology</a></li>	
		<li><a href="departments/anaesthesia.html">Anaesthesia</a></li>	-->
	</ul>
</div>
	        
<div class="navcol">
	<ul> 
	      <li><a href="Pruritus_Ani_details.php">Pruritus Ani</a></li>
	     <li><a href="Rectal_Polyps_details.php">Retal Polyps</a></li>
        <li><a href="pilonidal_sinus_details.php">Pilonodal Sinus</a></li>
	      <li><a href="constipation_details.php">Constipation</a></li>
	    <!--  <li><a href="departments/general-medicine.html">General Medicine</a></li>-->
		<!--<li><a href="departments/general--paediatric-surgery.html">General & Paediatric Surgery</a></li>	
		<li><a href="departments/ent.html">ENT</a></li>	
		<li><a href="departments/dental--maxillofacial-surgery.html">Dental & Maxillofacial Surgery</a></li>	
		<li><a href="departments/radiology.html">Radiology</a></li>	
		<li><a href="departments/casualty.html">Casualty</a></li>	
		<li><a href="departments/physiotherapy.html">Physiotherapy</a></li>	
		<li><a href="departments/psychology.html">Psychology</a></li>	
		<li><a href="departments/psychiatry.html">Psychiatry</a></li>	
		<li><a href="departments/neuro-surgery.html">Neuro Surgery</a></li>	
		<li><a href="departments/ophthalmology.html">Ophthalmology</a></li>	
		<li><a href="departments/gastroenterology.html">Gastroenterology</a></li>	
		<li><a href="departments/pulmonology.html">Pulmonology</a></li> -->
	</ul>
</div>
	        
<div class="navcol">
	<ul>
	</ul>
</div>

</div>
</div>
<!-- /parent -->



</div>
<!--/sidebar --><!--/sidebar --> 