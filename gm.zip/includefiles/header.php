<!DOCTYPE html>
<html lang="en">


<head>
<meta charset="utf-8" />
<title>GOOD MORNING SUPERSPECIALITY HOSPITAL</title>
<meta name="description" content="Visit our site!" />
<meta name="keywords" content="hospital">
<meta name="copyright" content="© Copyright 2021 Good Morning Super Speciality Hospital   All rights reserved
Powered by Blucor System Pvt.Ltd ">
<meta name="robots" content="NOODP,NOYDIR" />
<meta name="geo.region" content="IN-KL" />
<meta name="geo.position" content="9.991656;76.286356" />
<meta name="ICBM" content="9.991656, 76.286356" />
<meta name="Language" content="English" />
<meta name="Publisher" content="GOOD MORNING SUPER SPECIALITY HOSPITAL" />
<meta name="Revisit-After" content="Daily" />
<meta name="distribution" content="LOCAL" />
<meta name="Robots" content="INDEX, FOLLOW" />
<meta name="page-topic" content="Get in touch with us We will get back to you within a day.">
<meta name="YahooSeeker" content="INDEX, FOLLOW">
<meta name="msnbot" content="INDEX, FOLLOW">
<meta name="googlebot" content="index,follow"/>
<meta name="Rating" content="General"/> 
<meta name="allow-search" content="yes">
<meta name="expires" content="never">

<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<link rel="shortcut icon" href="assets/images/Gm_Hospital_FLogo_white.webp">
<link rel="stylesheet"  href="assets/css/normalize.css" />
<link rel="stylesheet"  href="assets/css/specialist-all.css" />
<link rel="stylesheet"  href="assets/css/hamburger.css" />
<link rel="stylesheet"  href="assets/css/slider.css" />
<link rel="stylesheet"  href="assets/css/font-awesome.css" />
<link rel="stylesheet"  href="assets/css/search.css" />
<link rel="stylesheet"  href="assets/css/animate.css" />
<link rel="stylesheet"  href="assets/css/carousel.css" />
<link rel="stylesheet"  href="assets/css/hover-style.css" />
<link rel="stylesheet"  href="assets/css/popup.css" />
<link rel="stylesheet"  href="assets/css/navside.css" />

<link rel="stylesheet"  href="assets/css/smk-accordion.css" />
<link rel="stylesheet"  href="assets/css/lightbox.css" />
<link rel="stylesheet"  href="assets/css/tabs.css" />

<!-- tetimonial css-->

<!--tetimonial css-->


<!-- Preloader -->
<script  src="assets/js/loader/jquery.min.js"></script>
<script >
	//<![CDATA[
		$(window).load(function() { // makes sure the whole site is loaded
			$('#status').fadeOut(); // will first fade out the loading animation
			$('#preloader').delay(350).fadeOut('slow'); // will fade out the white DIV that covers the website.
			$('body').delay(350).css({'overflow':'visible'});
		})
	//]]>
</script> 
<!-- popup -->
<!--<script type="text/javascript" src="js/mind9a9.js"></script>-->


<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-156459008-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-156459008-1');
</script>



<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>





