<style>

/*desktop  1023*/
@media only screen and (min-width:1024px) and (max-width:1440px) {
 .headerres {
    margin-top:-1%; margin-bottom:-1em;
height:9.5em;"
}
}
/*desktop end*/

/*tablet 768 and 1023*/
@media only screen and (min-width:768px)and (max-width:1023px) {
 .headerres {
    margin-top:-7%; margin-bottom:-2em;
height:10em;"
}
}
/*tablet 768 and 1023*/
@media only screen and (max-width:767px) {
 .headerres {
    margin-top:-7%; margin-bottom:-2em;
height:10em;"
}
}

/* for landspace all device =================================================*/
/* width 667*/
Landscape:

   @media only screen  and (max-device-width: 684px) 
   {
        .headerres {
    margin-top:10%; margin-bottom:-2em;
height:10em;"
}
   }
   
</style>
<body>

<!--preloader -->
<div id="preloader">
<div id="status">&nbsp;</div>
</div>
<!--/preloader -->

<!-- header -->
<header class="headerres" style="position:fixed!important;">
<div class="main">

<!--Logo -->
<div class="logo">
 <!--<a href="index.php"><img src="assets/images/gm_black_clr.png" alt=" Good Morning specialists hospital" height="100" width="200"></a> -->  
<a href="index.php"><img src="assets/images/Good_Morning_Logo.webp" alt=" Good Morning specialists hospital" height="100" width="200"></a></div>
<!--/logo -->

<!-- top-container -->
<div class="top-container">
    <div class="call">
    <div class="res-col"><p>
<a href="tel:+91 88884 00004" style=""><br>+9188884 00004</a></p> </div>
</div>
    <!--call res -->

<!--search-icon -->

<!--<div class="menu-icon">
<div class="menu-button">MENU</div>
</div>-->
<div class="search-conaiinter">
<div class="expanding-div">
    <div class="menu-icon">
        <div class="menu-button" style="color:#FFF!important;">MENU</div>
<!--<div id="sb-search" class="sb-search">-->
<!--<form  method="get" action="#">
<input class="sb-search-input" placeholder="Enter your search term..." type="text" value="" name="search" id="search">
<input class="sb-search-submit" type="submit" value="">
<span class="sb-icon-search"></span>
</form>-->
</div>
</div>
</div> 
<!--/search-icon -->

<!--call -->

<!--<div class="call ">
	
<!--<div class="tooltip">
<b class="hidden-xs">
<div class="fullwidth">	

<a href="tel:04842887800">0484-2887800</a> <span>(Physician)</span><br><a href="tel:9446501369">9446501369</a><span>(Proctologist) </span><br><a
href="tel:9072888893">9072888893</a><span>(Surgeons) </span><br><a 
href="tel:9633507632">9633507632</a><span>(Anaesthetist)</span></div>
</b>
</div> -->

<!--<div class="res-col">
<a href="tel:88886 00006">88886 00006</a> <br><span>(Physician)</span><!--<br><a href="tel:88886 00006">88886 00006</a><span>(Proctologist) </span><br><a
href="tel:88886 00006">88886 00006</a><span>(Surgeons) </span><br><a 
href="tel:88886 00006">88886 00006</a><span>(Anaesthetist)</span>--><!--</div>

</div>-->

<!--/call -->

<!--map -->



<!--<div class="ask-expert"><a href="ask-an-expert.php"><br>ASK AN EXPERT
<!-- <span>Click Here</span> -->

<!--</a></div> -->

<!--</div>

</a> -->
<!--/map -->



<!-- d-button-->
<!--<span class="d-button"><a href="#" id="open-right">OUR DEPARTMENTS</a></span>-->
<!-- d-button-->



<!--nav -->
<!--<nav>
<div class="menu-icon">
<div class="menu-button">MENU</div>
</div>
</nav>-->
<!--/nav -->

</div>
<!-- /top-container -->







</div>
</header>
<!-- /header -->