 <!-- footer -->

<footer> 
<!-- css for whastpp ,mail,phone-->
<style>
/* footer line css*/

@media only screen and (min-width: 500px) {
  .line{
  bgcolor:black!important;
  color:blue!important;
 /* font-size:10px;*/
  line-color:black;
  
display:none;  }
}

/*.highlight-button-white-border-wide:hover {border: 3px solid #ff9800;}
          .float{*/
  .float{
    position:fixed;
    width:60px;
    height:60px;
    bottom:56.5px;
    right:7px;
    background-color:#25d366;
    color:#FFF;
    border-radius:50px;
    text-align:center;
  font-size:30px;
    //box-shadow: 2px 2px 3px #999;
  z-index:100;
  
}
.ee{
    position:fixed;
    width:60px;
    height:60px;
  bottom:120px;
    right:7px;
    background-color:#0000ff;
   color:#FFF;
    border-radius:50px;
    text-align:center;
 font-size:30px;
   //box-shadow: 2px 2px 3px #999;
  z-index:100;
}
.my-float{
    margin:16px;
}
    
 
   
  </style>
  
  
  <!--text talk-->
  <!--Start of Tawk.to Script-->
<!--<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5ffeadcfa9a34e36b96be302/1ertddt69';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>-->
<!--End of Tawk.to Script-->
  <!--text chat tolk-->
 
  
  
  
  
<!-- --  whatsapp mail, phone------------->
         <a href="https://api.whatsapp.com/send?phone=+9188884 00004&text=Hello, Good Morning Superspeciality Hospital. I need more information." class="float animated fadeInUpBig delay-15s" target="_blank">
                        <i class="fa fa-whatsapp my-float"></i>
                    </a>
   
                    <a href="tel:+9188884 00004" class="ee animated fadeInUpBig delay-12s" target="_blank">
                    <i class="fa fa-phone my-float" ></i>
                      </a> 
                      
                      

             
<!-- close / whatspp mail, phone -------->
  <!--googlemap -->
 <!-- <div class="googlemap" width="70%">
    
  </div> -->
           <iframe src="https://www.google.com/maps/d/embed?mid=1w1LpP_T7dcS7Xtnt9E-R4vhZA7JFn7a_" width="100%" height="350"></iframe>
           
  <!--/googlemap -->
 <!-- <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3781.091498270294!2d73.7637935143701!3d18.614953871140397!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc2b99e0eee2aa9%3A0xad81299bb7b96ae7!2sGOOD%20MORNING%20SUPERSPECIALITY%20HOSPITAL%20%23%20DR.BHOSALE%20(%20M.S.)!5e0!3m2!1sen!2sin!4v1611235388934!5m2!1sen!2sin" width="100%" height="250" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
 -->

  <!--footer-left -->
  <div class="footer-left"> 
    
    <!--footer-address -->
    <div class="footer-address">
	<div class="container" style="padding-top:1px" >
      <div class="row">
        <div class="col-sm-12">
          <div class="col-md-4">
       <p class="subheading"> <strong><h4 style="color:#0892d0">&nbsp &nbsp &nbsp &nbsp DANGE CHOWK </h4>  </strong>
<p class="add"><i class="fa fa-map-o" aria-hidden="true"></i><strong> GOOD MORNING SUPERSPECIALITY HOSPITAL </strong><br>Dange Chowk,Near Fly Over Bridge,

<br>
Chinchwad.<br>
<!--<a href="https://goo.gl/maps/zK642Xxmxa1fDGSSA">Click Here </a> -->
 </p>
 <p class="add" style="margin-left:0px;"><i class="fa fa-phone" aria-hidden="true"></i> Phone : <a href="tel:88884 00004" style="color:blue;">88884 00004</a> 
<p class="add" style="margin-left:0px;"><i class="fa fa-envelope-o" aria-hidden="true"></i> Email: <a href="mailto:goodmorninghospital@gmail.com"  style="color:blue;">goodmorninghospital@gmail.com</a>
</p>
<p class="add" style="margin-left:0px;"><i class="fa fa-map-marker" aria-hidden="true"></i>  <a href="https://goo.gl/maps/QqeDy5VGKWkKxKV67" style="color:blue;">Map Location</a>
</div>
<div class="line">
<hr style=font-color:black;>
</div>



<div class="col-md-4">
        <p class="subheading"> <strong><h4 style="color:#0892d0">&nbsp &nbsp &nbsp &nbsp NIGDI </h4>  </strong>
<p class="add"><i class="fa fa-map-o" aria-hidden="true"></i><strong>
 GOOD MORNING CLINIC </strong><br>Kohinoor Arcade,


<br>Nigdi chowk, Near fly over bridge,<br> Nigdi.
 </p>
 
 <p class="add" style="margin-left:0px;"><i class="fa fa-phone" aria-hidden="true"></i> Phone : <a href="tel:88886 00006" style="color:blue;">88886 00006</a> 
<!--<p class="add" style="margin-left:0px;"><i class="fa fa-envelope-o" aria-hidden="true"></i> Email: <a href="mailto:dr_sandipbhosale@yahoo.com">dr_sandipbhosale@yahoo.com</a>
</p>-->
<p class="add" style="margin-left:0px;"><i class="fa fa-map-marker" aria-hidden="true"></i> <a href="https://goo.gl/maps/k7vTrUSBN2ydtrx46" style="color:blue;"> Map Location</a>
  </div>
  
  <div class="line">
<hr style=font-color:black;>
</div>



  <div class="col-md-4">
          <p class="subheading" > <strong><h4 style="color:#0892d0">&nbsp &nbsp &nbsp &nbsp PANEL CONSULTANT  </h4>  </strong>
<p class="add"> <i class="fa fa-map-o" aria-hidden="true"> </i><strong>SAI HOSPITAL<br></strong>
Chakan.<br>
<p class="add"> <i class="fa fa-map-o" aria-hidden="true"> </i><strong>HINJEWADI HOSPITAL</strong>
<br>Hinjewadi.
<br>
<!-- hitwebcounter Code START -->
<b> Visitors</b><br>


<!-- hitwebcounter Code START -->
<a >
<!--<img src="https://hitwebcounter.com/counter/counter.php?page=7747568&style=0027&nbdigits=5&type=page&initCount=100" title="Free Counter" Alt="web counter"   border="0" /></a> -->


<!-- Badge Code - Do Not Change The Code -->
<a class="hitCounter" href="#" target="_blank" title="Hit counter" data-name="45dae571ef5f1e0d09c81614d1513de5|5|ip|1|rgb(80, 175, 234);|#ffffff|small|s-hit"> Counter</a><script>document.write("<script type='text/javascript' src='https://visitorshitcounter.com/js/hitCounter.js?v="+Date.now()+"'><\/script>");</script>
<!-- Badge Code End Here -->
 </p>
 

  
<!-- <p class="add" style="margin-left:0px;"> <i class="fa fa-phone" aria-hidden="true"></i> Phone : <a href="tel:88886 00006">88886 00006</a>--> 
<!--<p class="add" style="margin-left:0px;"><i class="fa fa-envelope-o" aria-hidden="true"></i> Email: <a href="mailto:dr_sandipbhosale@yahoo.com">dr_sandipbhosale@yahoo.com</a>
</p> -->
<!--<p class="add" style="margin-left:0px;"><i class="fa fa-map-marker" aria-hidden="true"></i> Map <a href="https://goo.gl/maps/Hyve6K3WeCjxzWEk6">Location</a>-->
  </div>
<!--<p class="add" style="margin-left:15px;"><i class="fa fa-phone" aria-hidden="true"></i> Phone : <a href="tel:0484-2887800">88884 00004</a> 
<p class="add" style="margin-left:15px;"><i class="fa fa-envelope-o" aria-hidden="true"></i> Email: <a href="mailto:dr_sandipbhosale@yahoo.com">dr_sandipbhosale@yahoo.com</a>-->
<!--<p class="add"><i class="fa fa-fax" aria-hidden="true"></i> --><!-- Fax: (+91) 484 2392945, 2390347-->
<center><div class="copy" style="margin-left:0px;padding-top:50px;">© Copyright 2021 Good Morning Superspeciality Hospital. All rights reserved Powered  by <a href="https://blucorsys.com" target="_blank">Blucor Systems Pvt.Ltd</a>
  <!-- <br> <center> <a href="https://goo.gl/maps/Hyve6K3WeCjxzWEk6">Sitemap</a></center>-->
   
   <!--map -->


   
<div class="social" style="margin-left:15px;padding-top:40px;">
    <a href="https://www.facebook.com/Goodmorningsuperspeciality/" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a>
    
   <!-- <a href="https://www.google.com/search?q=good+morning+super+speciality+hospital&rlz=1C1CHBD_enIN859IN919&oq=good+morning+super+speciality+hospital&aqs=chrome..69i57j46i175i199j0i22i30l3j69i60.14449j0j4&sourceid=chrome&ie=UTF-8"
         target="_blank"> <i class="fa fa-google" aria-hidden="true"> </i></a>-->
     
         
         </a>
         <a href="https://www.google.com/search?q=good+morning+super+speciality+hospital&rlz=1C1CHBD_enIN859IN919&oq=good+morning+super+speciality+hospital&aqs=chrome..69i57j46i175i199j0i22i30l3j69i60.14449j0j4&sourceid=chrome&ie=UTF-8" target="_blank"><i class="fa fa-google" aria-hidden="true"></i></a>
         
         <br>
         <div class="center">
         <h4>Share website on</h4>
         <br>
          
         <a href ="mailto:info@example.com?&subject=&body=http://goodmorninghospital.blucorsys.com/ GMH" target="_blank"><i class ="fa fa-envelope" area-hidden="true"></i></a>
         
         <a href="whatsapp://send?text=http://goodmorninghospital.blucorsys.com" target="_blank"><i class="fa fa-whatsapp" aria-hidden="true"></i></a>
         
         
         
          <a href="https://twitter.com/intent/tweet?url=http://goodmorninghospital.blucorsys.com/&text=GMH" target="_blank"> 
          <i class="fa fa-twitter" aria-hidden="true"></i></a>
          
         <a href="https://www.linkedin.com/shareArticle?mini=true&url=http://goodmorninghospital.blucorsys.com/&title=&summary=GMH&source=" target="_blank"> <i class ="fa fa-linkedin-square" area-hidden="true"></i></a>
         
         <a href="https://www.facebook.com/sharer/sharer.php?u=http://goodmorninghospital.blucorsys.com/&title=&summary=GMH&source=" target="_blank"><i class="fa fa-facebook-official" aria-hidden="true"></i></a>
         
     <!--    <a href="https://pinterest.com/pin/create/button/?url=http://goodmorninghospital.blucorsys.com/&media=&description=GMH">
             <i class="fa fa-pinterest-p" aria-hidden="true"></i>
         </a>-->
         </div>
       
     <!--  <meta property="og:url"           content="http://goodmorninghospital.blucorsys.com/your-page.html" />
<meta property="og:type"          content="website" />
<meta property="og:title"         content="Good Morning Hospital " />
<meta property="og:description"   content="Your description" />
<meta property="og:image"         content="http://goodmorninghospital.blucorsys.com/assets/images/Good%20Morning%20Hospital%20-%20FINAL%20Logo-%20252x175-1.png" />
       
       <div class="fb-share-button" 
data-href="http://goodmorninghospital.blucorsys.com/your-page.html" 
data-layout="button_count">
</div> 
         
         <script>(function(d, s, id) {
var js, fjs = d.getElementsByTagName(s)[0];
if (d.getElementById(id)) return;
js = d.createElement(s); js.id = id;
js.src = "https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v3.0";
fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script> -->

         
         
         

         
         
         
         
         
         <?php
         
           //$url="http://goodmorninghospital.blucorsys.com";
                             //$url= urlencode($url);
                             ?>
          <!--<a class="w-inline-block social-share-btn fb" -->
          <!--      href="https://www.facebook.com/sharer/sharer.php?u=<?php //echo $url;?>" target="_blank">Sahre Facebook</a>-->
              <!--  <iframe src="https://www.facebook.com/plugins/share_button.php?href=http%3A%2F%2Fgoodmorninghospital.blucorsys.com%2F&layout=button_count&size=small&width=77&height=20&appId" width="77" height="20" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowfullscreen="true" allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"></iframe>-->
                
              <!--  <div class="fb-share-button" 
data-href="https://www.your-domain.com/your-page.html" 
data-layout="button_count">
</div>-->

         
         
         <!--<a href="https://www.youtube.com/channel/UC6XgZMJnNdqzRCIGmv-J5cg" target="_blank"><i class="fa fa-youtube" aria-hidden="true"></i></a>-->
         <!--<a href="#" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a>--></div>    </div>        </div> </center>
<!--<div class="social" style="margin-left:15px;"><a href="#" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a><a href="#" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a><a href="#" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a><!--<a href="https://www.youtube.com/channel/UC6XgZMJnNdqzRCIGmv-J5cg" target="_blank"><i class="fa fa-youtube" aria-hidden="true"></i></a>--><!--<a href="#" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a></div>    </div> -->
    <!--/footer-address --> 
    
  </div>
  <!--/footer-left --> 
  </div>
  <!--<div class="social" style="margin-left:15px;"><a href="#" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a><a href="#" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a><a href="#" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a><!--<a href="https://www.youtube.com/channel/UC6XgZMJnNdqzRCIGmv-J5cg" target="_blank"><i class="fa fa-youtube" aria-hidden="true"></i></a>--><!--<a href="#" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a></div>    </div> -->
 <!--<center> <div class="copy" style="margin-left:15px;">© Copyright 2020 Good Morning Superspeciality Hospital. All rights reserved Powered  by <a href="#" target="_blank">Blucor System Pvt.Ltd</a></div> </center> -->
 
 
</footer>
<!--/footer -->