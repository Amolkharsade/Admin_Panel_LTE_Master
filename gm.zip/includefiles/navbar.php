<!--Navigation -->
<!-- open/close -->
<!--Navigation -->
<style>
    .row {
    margin-right: -15px!important;
    margin-left: 15px!important;}
    
    .container{
        margin-right:-20%!important;
        margin-left:-0%!important;
    
    }
    .overlay-menu
    {
         margin-right:-20%!important;
        margin-left:-0%!important;
    }
</style>
<section class="overlay-menu">
<div class="menu-icon"><div class="closebutton"></div></div>

<div class="container" style= "">
<div class="row">
<!--menu --><div class="columns menu-col"><h2>Main Pages</h2>
<ul>
<li><a href="index.php">Home</a></li>
<!--
<li><a href="appointment.php">Appointment</a></li>-->

<li><a href="doctors.php">Team Of Doctor</a></li>
<li> <a href="about-us1.php">   About Us </a></li>
<li> <a href="testimonials.php">          Patient Say              </a></li>
<li> <a href="gallery.php">          Media              </a></li>
<li> <a href="contact-us.php">          Contact Us              </a></li>

<!--<li><a href="health-checkup-package.php">Health checkup packages</a></li>-->
<!--<li><a href="news.php">News &amp; Events</a></li>-->
<!--<li><a href="testimonials.php">Patient Testimonials</a></li>-->
<!--<li><a href="#">Courses</a></li>-->
<!--<li><a href="blog/index.html">Blog</a></li>-->
<!--<li><a href="careers.php">Careers</a></li> -->

</ul>
</div>


<!--menu -->	  	   <!--menu --><div class="columns menu-col"><h2>Speciality</h2>
<ul>
    <li> <a href="piles_details.php"> Piles</a></li>
     <li> <a href="Fissure_details.php"> Fissure</a></li>
      <li> <a href="Fistula_details.php">Fistula</a></li>
       <li> <a href="Abscess_details.php"> Abscess</a></li>
        <li> <a href="Pruritus_Ani_details.php"> Pruritus Ani</a></li>
         <li> <a href="Rectal_Polyps_details.php"> Rectal Polyps </a> </li>
          <li> <a href="pilonidal_sinus_details.php"> Pilonidal Sinus</a></li>
           <li> <a href="constipation_details.php"> Constipation</a></li>
<!--<li><a href="laboratory.php">Laboratory</a></li>-->
<!--<li><a href="insurance.php">Insurance</a></li>-->
<!--<li><a href="emergency-services.php">Emergency Services</a></li>-->
<!--<li><a href="international-patients.php">For International Patients</a></li>-->
</ul>
</div>

<!--menu --><div class="columns menu-col"><h2>Treatments</h2>
<ul> 
   <li> <a href="laser_surgery.php"> Laser Surgery </a></li>
   <li> <a href="Injection_Therapy.php"> Injection Therapy </a></li>
   <li> <a href="seton.php"> Seton </a></li>
   <li> <a href="Barrons_Brand.php"> Barron's Band </a></li>
   <li> <a href="infrared_coagulation.php"> Infrared Coagulation </a></li>
   <li> <a href="stapler_surgery.php"> Stapler Surgery </a></li>
  <!-- <li> <a href="">  </a></li>-->
<!--<li><a href="free-cancer-treatment-in-kerala.php" target="_blank">Snehathanal</a></li> -->
<!--<li><a href="fclps.php">Free Palate Surgery (Smile Train)</a></li>
<li><a href="our_treatment.php">Therapy & Surgery Treatment</a></li>-->
</ul>
</div> 

<!--menu --><!--menu --><!--<div class="columns menu-col"><h2>About Us</h2>
<ul>

<li><a href="about-us1.php">Overview</a></li>
 <li><a href="contact-us.php">Contact Us</a></li>-->
<!--<li><a href="our-director.php">Our Director</a></li> -->
<!--<li><a href="mission.php">Mission</a></li>
<li><a href="vision.php">Vision</a></li>-->
<!--<li><a href="milestone.php">Milestone</a></li> -->
<!--</ul>
</div>-->
<!--menu --><!--menu --><!--<div class="columns menu-col"><h2>Media Gallery</h2>
<ul> 
<li><a href="testimonials.php">Patient Say</a></li> -->
<!--<li><a href="#">Video Gallery</a></li>-->
<!--<li><a href="gallery.php">Image Gallery</a></li>-->
<!--<li><a href="before-after.html">Before &amp; After Photos</a></li> -->
<!--</ul>
</div> -->
<!--menu -->

</div>
</div>
</section>
<!--/Navigation --><!--/Navigation --> 