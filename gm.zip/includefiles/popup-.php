<?php include "includefiles/connection.php"; ?>
<!-- popup form -->
 <!-- slide-out-div-->
<div class="slide-out-div vertical-button">
<a class="handle" href="#">Book An Appointment</a>
<form action="" method="POST" autocomplete="off">

<input type="text" name="name" id="name" pattern="[a-zA-Z ]+" class="fieldset2 secondary" onCopy="return false" onDrag="return false" onDrop="return false" onPaste="return false" required value=""  placeholder="Name* ">

<input type="text" name="phone" id="phone" pattern="[0-9]{10}" title="10 numbers minimum" onKeyPress="return isNumberKey(event)" onCopy="return false" onDrag="return false" onDrop="return false" onPaste="return false" required class="fieldset2 secondary" value="" placeholder="Mobile Number* ">

<input name="email" type="email" id="email" class="fieldset2 secondary" onCopy="return false" onDrag="return false" onDrop="return false" onPaste="return false" required value="" placeholder="Email Address*">

<select name="department" id="department" class="fieldset2 secondary" required title="Please Select Department">
    <option>Select Department</option>
    <option value="Piles" >Piles</option>
          <option value="Fissure" >Fissure</option>
                                <option value="Fistula" >Fistula</option>
                                <option value="Abscess" >Abscess</option>
                                <option value="Pruritus Ani" >Pruritus Ani</option>
                                <option value="Rectal Polyps" >Rectal Polyps</option>
                                <option value="Pilonidal Sinus" >Pilonidal Sinus</option>
                                <option value="Constipation" >Constipation</option>
                                
    </select>
<span class="error"></span>

<select name="select_doctor" id="select_doctor" class="fieldset2  secondary" required="" title="Please Select Doctor">
    <option value="">Select Doctor</option>
    <option value="DR. SANDIP BHOSALE">DR. SANDIP BHOSALE</option>
    <option value="DR. PREETI BHOSALE">DR. PREETI BHOSALE</option>
    <option value="DR. ASHOK LANDAGE">DR. ASHOK LANDAGE</option>
    <option value="DR.DEVDATTA PADYE">DR.DEVDATTA PADYE</option>
    <option value="DR.PRASHANT RAJWADE">DR.PRASHANT RAJWADE</option>
    <option value="DR. MILIND APSANGIKAR">DR. MILIND APSANGIKAR</option>
    <option value="DR. ROHINI VEER">DR. ROHINI VEER</option>
    <option value="DR.PRIYANKA POTE">DR.PRIYANKA POTE</option>
    <option value="DR. DILIP MEHTA">DR. DILIP MEHTA</option>
    </select>
<span class="error"></span>

<div style="display:none;"><input type="text" name="hiddendayvalue" id="hiddendayvalue"></div>
<input name="txt_appdate" type="date" class="fieldset2 secondary" onCopy="return false" onDrag="return false" onDrop="return false" onPaste="return false" required id="txt_appdate" value="" placeholder="Appointment Date*">

<textarea name="message" id="message" rows="4" class="fieldset2 secondary" onCopy="return false" onDrag="return false" onDrop="return false" onPaste="return false"  placeholder="Message " maxlength="1000"></textarea>


<!--<div class="capt-pop">
   <h2 class="bgcap-h2" type="text" id="mainCaptcharead"></h2>
   <input type="button" class="refresh-cap" id="refresh_cap" onclick="GetCaptcha();"/>
   <input type="text" name="txtInputcap" id="txtInputcap" onCopy="return false" onDrag="return false" onDrop="return false" onPaste="return false" required>
</div>-->


<input name="Submit_popup_btn" id="Submit_apppopup_btn" value="Book Now" class="sendbutton" type="submit" onclick="ValidPopCaptcha();">

</form>
<?php
      if(isset($_POST['Submit_popup_btn'])){
            $name = $_POST['name'];
            $phone = $_POST['phone'];
            $email = $_POST['email'];
            $message = $_POST['message'];
            $department = $_POST['department'];
            $doctor = $_POST['select_doctor'];
            $ap_date = $_POST['txt_appdate'];
            $reg_date = date('Y-m-d H:i:s');
            
            //$connect =


      $sql = "INSERT INTO appointment (name, mobile, email, message, department, doctor, ap_date, reg_date)VALUES ('$name', '$phone', ' $email', '$message', '$department', ' $doctor', '$ap_date', '$reg_date')";
              if ($connect->query($sql) === TRUE) {
              echo"Appointment request Sent.";
                  
            } else {
              echo "Error: " . $sql . "<br>" . $connect->error;
            }

      }
?>
</div> 
<!-- /slide-out-div-->
