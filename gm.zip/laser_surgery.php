	    <?php include "includefiles/header.php"; ?>

<style>
 @media only screen and (max-width: 700px) {
	 
	.banner1 {
     /* background-image: url(uploads/banners/tratment_image.jpg);*/
	  
	   margin-top:9%;
	margin-left:0%;
	margin-right:0%;
      width:100%;height:75vh!important;float:left;position:relative;background-position:center;background-size:cover;background-repeat:no-repeat; padding:1px;
    
  }
  
 }
 /* for mobile  */


  .banner1 {
    /*  background-image: url(uploads/banners/tratment_image.jpg);*/
      background-image: url(uploads/pagebanner/laser-surgery.webp);
  }
</style>
</head>


<?php include "includefiles/header2.php";?>




<!--inner-banner--> 
<div class="inner-banner jarallax banner1">

</div>
<!--/inner-banner--> 


<!--START INNER CONTENT -->
<section class="pad">

<div class="main">



 	<!--row -->
<div class="row">
  <div class="col-sm-12">
    <div class="col-sm-5" style="margin-left:-20px!important;">
	
       <h2 class="page-title"><center>LASER SURGERY</center> </h2>
      <img src="uploads/images/treatment/laser_surgery.webp" style="margin-top: 5%;">
  </div>
    <div class="col-sm-7" style="margin-top:5%;">
	<!--row -->
<div class="row">
<div class="margin-bottom">
<!-- Accordion begin --><div class="accordion_example1" style="margin-left:-20px!important;">	
	<!-- item1 --><div class="accordion_in "><div class="acc_head">What Is It</div><div class="acc_content"><h3 class="subheading text-green"></h3><p>Laser surgery is a type of surgery that uses special light beams instead of instruments, such as scapels, to perform surgical procedures. There are several different types of lasers, each with characteristics that perform specific functions during surgery.</p></div></div><!-- item1 -->
	<!-- item2 --><div class="accordion_in"><div class="acc_head">Indications</div><div class="acc_content"><p></p><h3 class="subheading text-green"></h3><ul class="list"><li>PILES </li><li>FISSURE</li> <li>FISTULA</li> <li>PILONIDAL SINUS</li></ul>  </div></div><!-- item2 -->
	<!-- item3 --><div class="accordion_in"><div class="acc_head">Benefits</div><div class="acc_content"><p></p><h3 class="subheading text-green"></h3><ul class="list"><li>Bleeding stops within 24-48 hrs.</li><li>Virtually painless treatment.</li><li>No incontinence (No loss of control on motion).</li><li>No Hospitalization require.</li><li>No daily dressing require.</li><li>High success rate. </li> <li>Fast recovery. </li><li>Patient can go home within 24 Hr.</li></ul>  </div></div><!-- item3 -->
				   
				   
				   
	</div><!-- Accordion end -->
</div>
</div>


  </div>
</div>





</div>
</section>
<!--/INNER CONTENT END -->


 
   
  <!-- footer -->


     <!-- footer -->

<?php include "includefiles/footer.php"; ?>
<!--/footer --> 

<!-- open/close --> 
<!--Navigation -->
<!-- open/close -->
<!--Navigation -->
<?php include "includefiles/navbar.php"; ?>
<!--/Navigation --><!--/Navigation --> 

<!-- department-menu --> 
<!--sidebar -->
<!--sidebar -->
<?php include "includefiles/sidebar.php"; ?>
<!--/sidebar --><!--/sidebar --> 
<!--/department-menu --> 

<!-- go-top-->
<?php include "includefiles/gotoup.php"; ?>
<!-- /go-top-->

  
<!-- /slide-out-div-->
<?php include "includefiles/scriptall.php";?>

</body>

</html> 
   
   
   
   
   
   

